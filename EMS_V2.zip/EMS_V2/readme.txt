 The program uses Lab2Etrg15@ORCL11G to login, don't change the credentails. Necessary tables are already present in that login.

 Execute MainClass in ems.ui package


 Tables needed if credentails changed----------
 1-Grade_Master
 2-Employee
 3-Department


 CREATE TABLE Grade_Master(Grade_Code varchar2(20),Description varchar2(20),Min_Salary number,Max_Salary number);

 insert into Grade_Master values('M1','Grade1',1000,2000);
 insert into Grade_Master values('M2','Grade2',2001,3000);
 insert into Grade_Master values('M3','Grade3',3001,4000);
 insert into Grade_Master values('M4','Grade4',4001,5000);
 insert into Grade_Master values('M5','Grade5',5001,6000);
 insert into Grade_Master values('M6','Grade6',6001,7000);
 insert into Grade_Master values('M7','Grade7',7001,8000);

 Table Employee already exists.
 Table department should have department ID and departmentName
 
 Updates
  in Employee Class
	no empDepartment, insted empdesigation, managerid changed to string
  in Department Class
	deptId and deptName
 
