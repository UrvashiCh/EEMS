package com.cg.ems.dao;

public interface QueryMapper 
{
	public static final String EMP_INSERT_QRY="INSERT INTO Employee VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
	
	public static final String GET_EMP_SALARY="SELECT Min_Salary,Max_Salary FROM Grade_Master WHERE "
			+ "GRADE_CODE=?";
	
	public static final String GET_EMP_DEPARTMENT="SELECT Dept_Name FROM Department WHERE "
			+ "Dept_Id=?";
	public static final String GET_DEPARTMENT="SELECT * FROM Department";
	
	public static final String GET_GRADECODE="SELECT * FROM Grade_Master";
	public static final String GET_ALL_EMPLOYEE="SELECT * FROM Employee";

}
