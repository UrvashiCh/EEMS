package com.cg.ems.dao;

public class EmployeeDaoImpl implements EmployeeDao {

}
