package com.cg.ems.service;

public interface EmployeeService {

}
