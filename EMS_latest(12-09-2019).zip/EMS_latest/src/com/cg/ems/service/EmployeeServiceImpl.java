package com.cg.ems.service;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;

import com.cg.ems.dao.EmployeeDao;
import com.cg.ems.dao.EmployeeDaoImpl;
import com.cg.ems.dto.Employee;
import com.cg.ems.dto.LeaveRecords;
import com.cg.ems.exception.EmployeeException;

public class EmployeeServiceImpl implements EmployeeService
{	EmployeeDao empDao = null;	
	public EmployeeServiceImpl() {
		empDao = new EmployeeDaoImpl();
	}

	@Override
	public int fetchLeaveBudget(int lId) throws ClassNotFoundException, SQLException, IOException {
		return empDao.fetchLeaveBudget(lId);
	}

	@Override
	public boolean newLeaveRequest(LeaveRecords leaveRecord) throws ClassNotFoundException, SQLException, IOException {
		return empDao.newLeaveRequest(leaveRecord);
	}

	@Override
	public boolean updateLeaveRequest(int lId, String updatedStatus, int leaveBal) throws ClassNotFoundException, SQLException, IOException {
		return empDao.updateLeaveRequest(lId,updatedStatus,leaveBal);
	}

	@Override
	public ArrayList<LeaveRecords> fetchAllLeaveRequests(String mngrId) throws ClassNotFoundException, SQLException, IOException {
		return empDao.fetchAllLeaveRequests(mngrId);
	}

	@Override
	public boolean findEmployeePastLeaves(String empId) throws ClassNotFoundException, SQLException, IOException {
		return empDao.findEmployeePastLeaves(empId);
	}

	@Override
	public ArrayList<LeaveRecords> fetchPreviousRequests(String empId) throws ClassNotFoundException, SQLException, IOException, EmployeeException {
		return empDao.fetchPreviousRequests(empId);
	}

	@Override
	public Employee searchEmployeeById(String id) throws ClassNotFoundException, EmployeeException, SQLException, IOException {
		return empDao.searchEmployeeById(id);
	}

	@Override
	public ArrayList<Employee> searchEmployeeByFirstName(String fn) throws ClassNotFoundException, EmployeeException, SQLException, IOException {
		return empDao.searchEmployeeByFirstName(fn);
	}

	@Override
	public ArrayList<Employee> searchEmployeeByLastName(String ln) throws ClassNotFoundException, EmployeeException, SQLException, IOException {
		return empDao.searchEmployeeByLastName(ln);
	}

	@Override
	public ArrayList<Employee> searchEmployeeByDeptId(int id) throws ClassNotFoundException, EmployeeException, SQLException, IOException {
		return empDao.searchEmployeeByDeptId(id);
	}

	@Override
	public ArrayList<Employee> searchEmployeeByGrade(String grade) throws ClassNotFoundException, EmployeeException, SQLException, IOException {
		return empDao.searchEmployeeByGrade(grade);
	}

	@Override
	public ArrayList<Employee> searchEmployeeByMaritalStatus(String ms) throws ClassNotFoundException, SQLException, IOException, EmployeeException {
		return empDao.searchEmployeeByMaritalStatus(ms);
	}

	@Override
	public int fetchLeaveDuration(int lId) throws ClassNotFoundException, SQLException, IOException {
		return empDao.fetchLeaveDuration(lId);
	}

	@Override
	public int fetchInitialLeaveBudget(String empId) throws ClassNotFoundException, SQLException, IOException {
		return empDao.fetchInitialLeaveBudget(empId);
	}
}
