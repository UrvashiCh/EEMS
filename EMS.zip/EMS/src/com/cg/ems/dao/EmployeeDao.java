package com.cg.ems.dao;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;

import com.cg.ems.dto.LeaveRecords;
import com.cg.ems.exception.EmployeeException;

public interface EmployeeDao {
	public int fetchLeaveBudget(String empId) throws ClassNotFoundException, SQLException, IOException;
	public boolean newLeaveRequest(LeaveRecords leaveRecord) throws ClassNotFoundException, SQLException, IOException;
	public boolean updateLeaveRequest(int lId, String updatedStatus) throws SQLException, ClassNotFoundException, IOException;
	public ArrayList<LeaveRecords> fetchAllLeaveRequests(String empId) throws SQLException, ClassNotFoundException, IOException;
	public boolean findEmployeePastLeaves(String empId) throws ClassNotFoundException, SQLException, IOException;
	public ArrayList<LeaveRecords> fetchPreviousRequests(String empId) throws ClassNotFoundException, SQLException, IOException, EmployeeException;
}
