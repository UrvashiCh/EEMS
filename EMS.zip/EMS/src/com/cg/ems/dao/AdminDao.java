package com.cg.ems.dao;

public interface AdminDao {

}
