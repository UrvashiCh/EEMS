package com.cg.ems.dao;

import java.io.IOException;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import com.cg.ems.dto.LeaveRecords;
import com.cg.ems.exception.EmployeeException;
import com.cg.ems.util.DBUtil;
import com.cg.ems.util.QueryMapper;

public class EmployeeDaoImpl implements EmployeeDao {
	Connection con = null;
	Statement st = null;
	PreparedStatement pst = null;
	ResultSet rs = null;
	@Override
	public int fetchLeaveBudget(String empId) throws ClassNotFoundException, SQLException, IOException {
		con = DBUtil.getCon();
		pst = con.prepareStatement(QueryMapper.EMP_fetchLeaveBudget_QRY);
		pst.setString(1, empId);
		rs = pst.executeQuery();
		int result = 0;
		while(rs.next()) {
			result = rs.getInt(1);
		}
		return result;
	}
	
	@Override
	public boolean newLeaveRequest(LeaveRecords leaveRecord) throws ClassNotFoundException, SQLException, IOException {
		con = DBUtil.getCon();
		pst = con.prepareStatement(QueryMapper.EMP_addLeaveRequest_QRY);
		pst.setString(1, leaveRecord.getEmpId());
		pst.setInt(2, leaveRecord.getLeaveBalance());
		pst.setInt(3, leaveRecord.getNoOfDays());
		pst.setDate(4, Date.valueOf(leaveRecord.getFromDate()));
		pst.setDate(5, Date.valueOf(leaveRecord.getToDate()));
		pst.setString(6, leaveRecord.getStatus());
		int insertStatus = pst.executeUpdate();
		if(insertStatus>0){
			leaveRecord.setLeaveId(getLeaveId());
			return true;
		}
		return false;
	}

	private int getLeaveId() throws SQLException {
		int id=0;
		Statement stmt = con.createStatement();
		ResultSet rs = stmt.executeQuery(QueryMapper.EMP_fetchLeaveId_QRY);			
		if(rs.next()){
			id = rs.getInt(1);
		}
		return id;
	}

	@Override
	public boolean updateLeaveRequest(int lId, String updatedStatus) throws SQLException, ClassNotFoundException, IOException {
		con = DBUtil.getCon();
		pst = con.prepareStatement(QueryMapper.MGR_updateleaveStatus_QRY);
		pst.setString(1, updatedStatus);
		pst.setInt(2, lId);
		int updateStatus = pst.executeUpdate(); 
		if(updateStatus>0) {
			return true;
		}
		else {
			return false;
		}
	}

	@Override
	public ArrayList<LeaveRecords> fetchAllLeaveRequests(String empId) throws SQLException, ClassNotFoundException, IOException {
		con = DBUtil.getCon();
		pst = con.prepareStatement(QueryMapper.MGR_fetchAllLeaveRequest_QRY);
		pst.setString(1, empId);
		rs = pst.executeQuery();
		ArrayList<LeaveRecords> list = new ArrayList<LeaveRecords>();
		LeaveRecords lr = null;
		while(rs.next()) {
			lr = new LeaveRecords(); 
			lr.setLeaveId(rs.getInt(1));
			lr.setEmpId(rs.getString(2));
			lr.setLeaveBalance(rs.getInt(3));
			lr.setNoOfDays(rs.getInt(4));
			lr.setFromDate(rs.getDate(5).toLocalDate());
			lr.setToDate(rs.getDate(6).toLocalDate());
			lr.setStatus(rs.getString(7));
			list.add(lr);
		}
		return list;
	}

	@Override
	public boolean findEmployeePastLeaves(String empId) throws ClassNotFoundException, SQLException, IOException {
		con = DBUtil.getCon();
		pst = con.prepareStatement(QueryMapper.EMP_leavehistory_QRY);
		pst.setString(1, empId);
		rs = pst.executeQuery();
		if(rs.next()) {
			return true;
		}
		else{
			return false;
		}
	}

	@Override
	public ArrayList<LeaveRecords> fetchPreviousRequests(String empId) throws ClassNotFoundException, SQLException, IOException, EmployeeException {
		ArrayList<LeaveRecords> list = null;
		try {
			con = DBUtil.getCon();
			pst = con.prepareStatement(QueryMapper.EMP_previousleavehistory_QRY);
			pst.setString(1, empId);
			rs = pst.executeQuery();
			list = new ArrayList<LeaveRecords>();
			LeaveRecords lr = null;
			while(rs.next()) {
				lr = new LeaveRecords(); 
				lr.setLeaveId(rs.getInt(1));
				lr.setEmpId(rs.getString(2));
				lr.setLeaveBalance(rs.getInt(3));
				lr.setNoOfDays(rs.getInt(4));
				lr.setFromDate(rs.getDate(5).toLocalDate());
				lr.setToDate(rs.getDate(6).toLocalDate());
				lr.setStatus(rs.getString(7));
				list.add(lr);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return list;
	}
}
