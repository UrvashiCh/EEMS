package com.cg.ems.dao;

public class AdminDaoImpl implements AdminDao{

}
