package com.cg.ems.ui;

import java.io.IOException;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.Scanner;
import com.cg.ems.dto.Department;
import com.cg.ems.dto.Employee;
import com.cg.ems.dto.GradeMaster;
import com.cg.ems.dto.LeaveRecords;
import com.cg.ems.dto.UserMaster;
import com.cg.ems.exception.EmployeeException;
import com.cg.ems.service.AdminService;
import com.cg.ems.service.AdminServiceImpl;
import com.cg.ems.service.EmployeeService;
import com.cg.ems.service.EmployeeServiceImpl;
import com.cg.ems.service.LoginService;
import com.cg.ems.service.LoginServiceImpl;


//189006
//urvashi
//189008
//ram
public class EmsMain {
	static Scanner sc = new Scanner(System.in);
	static LoginService loginService = null;
	static AdminService adminService = null;
	static EmployeeService empService = null;
	static boolean login = false;
	public static void main(String[] args) throws ClassNotFoundException, SQLException, IOException {
		loginService = new LoginServiceImpl();
		adminService = new AdminServiceImpl();
		empService = new EmployeeServiceImpl();
		
		while (!login) {
			System.out.println(
					"******************************Welcome to Employee Management System*******************************");
			System.out.println(" 1. Login As Admin.");
			System.out.println(" 2. Login as Employee.");
			System.out.println("You Want To Login As...........");
			int choice = sc.nextInt();
			String id;
			String pass;
			UserMaster um;
			switch(choice) {
			case 1:
				System.out.println("Enter AdminID....");
				id = sc.next();
				System.out.println("Please Enter your Password....");
				pass = sc.next();
				um = new UserMaster(id, pass);
				try {
					login=true;
					AdminLogin(um);
				}catch (Exception e) {
					System.out.println(e.getMessage());
					login=false;
				}
				break;

			case 2:
				System.out.println("Enter EmployeeID....");
				id = sc.next();
				System.out.println("Please Enter your Password....");
				pass = sc.next();
				um = new UserMaster(id, pass);
				try {
					login=true;
					EmployeeLogin(um);
				} catch (Exception e) {
					System.out.println(e.getMessage());
					login=false;
				}
				break;

			default:
				System.out.println("Invalid Option");
				break;
			}

		}
	}

	public static void AdminLogin(UserMaster um) throws SQLException, EmployeeException, ClassNotFoundException, IOException {
		String admin = loginService.EmployeeType(um);
		while (login) {
			System.out.println(
					"*********************WELCOME TO " + admin.toUpperCase() + " LOGIN****************************");
			System.out.println("Enter Your Choice...");
			System.out.println("1. Add Employee");
			System.out.println("2. Modify Employee");
			System.out.println("3. Search Employee");
			System.out.println("4. Display All Employees");
			System.out.println("5. Sign Out");
			int choice = sc.nextInt();
			switch (choice) {
			case 1:
				addEmployee();
				break;
			case 2:
				modifyEmployee();
				break;
			case 3:
				searchEmployee();
				break;
			case 4:
				displayAllEmployees();
				break;
			case 5:
				login = false;
				break;
			default:
				break;
			}
		}
	}

	private static void EmployeeLogin(UserMaster um) throws ClassNotFoundException, SQLException, IOException, EmployeeException {
		String user = loginService.EmployeeType(um);
		String type[] = user.split(" ", 2);
		if (type[0].equals("Employee")) {
			while (login) {
				System.out.println(
						"**********************WELCOME " + type[1].toUpperCase() + " TO EMPLOYEE LOGIN***************** ");

				System.out.println("Enter Your Choice...");
				System.out.println("1. Search Employee");
				System.out.println("2. Apply for Leave");
				System.out.println("3. Previous Leave Requests");
				System.out.println("4. Sign Out");
				int choice = sc.nextInt();
				switch (choice) {
				case 1:
					searchEmployee();
					break;
				case 2:
					applyLeave(um.getUserId());
					break;
				case 3:
					previousLeave(um.getUserId());
					break;
				case 4:
					login = false;
					break;
				default:
					break;
				}
			}

		} else if (type[0].equals("Manager")) {
			while (login) {
				System.out.println(
						"***********************WELCOME " + type[1].toUpperCase() + " TO MANAGER LOGIN****************** ");
				System.out.println("Enter Your Choice...");
				System.out.println("1. Search Employee");
				System.out.println("2. Leave Requests");
				System.out.println("3. Sign Out");
				int choice = sc.nextInt();
				switch (choice) {
				case 1:
					searchEmployee();
					break;
				case 2:
					leaveRequests(um.getUserId());
					break;
				case 3:
					login = false;
					break;
				default:
					break;
				}
			}
		}
	}

	private static void addEmployee() throws EmployeeException, ClassNotFoundException, SQLException, IOException {
			String eId;
			do
			{
				System.out.println("Enter Employee ID:");
				eId=sc.next();	
				if(!adminService.validateEmpId(eId))
				{
					System.out.println("Employee ID Should be 6 digits:");
				}
				
			}while(!adminService.validateEmpId(eId));
		
			String eFName;
			do
			{
				System.out.println("Enter Employee First Name:");
				eFName=sc.next();
				if(!adminService.validateName(eFName, 1))
				{
					System.out.println("Invalid First Name, Should start with Capital:\n \n");
				}
			}while(!adminService.validateName(eFName, 1));
			
			String eLName;
			do
			{
				System.out.println("Enter Employee Last Name:");
				eLName=sc.next();
				if(!adminService.validateName(eLName, 2))
				{
					System.out.println("Invalid Last Name, Should start with Capital:\n \n");
				}
			}while(!adminService.validateName(eLName, 2));
			
			String eDob=null;
			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
			boolean DOBflag=false;
			LocalDate eDOB=null;
			do
			{
			System.out.println("Enter Employee Date of Birth:(dd/MM/yyyy)");
			eDob=sc.next(); 
			//boolean choice=adminService.isValidDateFormat(eDob);
			if(!adminService.isValidDateFormat(eDob))
			{
				System.out.println("Date should be valid and should be in dd/MM/yyyy format");
				DOBflag=false;
			}
			else if(adminService.isValidDateFormat(eDob))
			{
				eDOB = LocalDate.parse(eDob, formatter);
				if(!adminService.isValidDOB(eDOB))
				{
					System.out.println("Employee should be atleast 20 years old");
					DOBflag=false;
				}
				else if(adminService.isValidDOB(eDOB))
				{
					DOBflag=true;
				}
			}
			}while(!DOBflag);
			
			String eDoj=null;
			boolean DOJflag=false;
			LocalDate eDOJ = null;
			do
			{
				System.out.println("Enter Employee Date of Joining:(dd/MM/yyyy)");
				eDoj=sc.next();
				if(!adminService.isValidDateFormat(eDoj))
				{
					System.out.println("Date should be valid and should be in dd/MM/yyyy format");
					DOJflag=false;
				}
				else if(adminService.isValidDateFormat(eDoj))
				{
					eDOJ = LocalDate.parse(eDoj, formatter);
					if(!adminService.isValidDOJ(eDOB,eDOJ))
					{
						System.out.println("Employee Date Of Joining is not valid");
						DOJflag=false;
					}
					else if(adminService.isValidDOJ(eDOB,eDOJ))
					{
						DOJflag=true;
					}
				}
			}while(!DOJflag);
						
			ArrayList<Department> depList = null;
			try {
				depList = adminService.displayDepartment();
			} catch (ClassNotFoundException | SQLException | IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			ArrayList <Integer> validateDepId=new ArrayList<Integer>();
			System.out.println("\n-----------------------------------------------");
			System.out.println("Department ID\t\t Department Name");
			System.out.println("\n-----------------------------------------------");
			for(Department dep:depList)
			{
				System.out.println(dep.getDeptID()+"\t\t\t"+dep.getDeptName());
				validateDepId.add(dep.getDeptID());
			}
			System.out.println("-------------------------------------------------");
			
			int eDepId;
			do
			{
				System.out.println("Select Department ID:");
				eDepId=sc.nextInt();
				if(!adminService.validateDeptID(validateDepId,eDepId))
				{
					System.out.println("Selected Department ID: "+eDepId+" is Invalid:\n \n");
					
					System.out.println("-----------------------------------------------");
					System.out.println("Department ID\t\t Department Name");
					System.out.println("\n-----------------------------------------------");
					for(Department dep:depList)
					{
						System.out.println(dep.getDeptID()+"\t\t\t"+dep.getDeptName());
						validateDepId.add(dep.getDeptID());
					}
					System.out.println("-------------------------------------------------");
				}
			}while(!adminService.validateDeptID(validateDepId,eDepId));
			
			ArrayList<GradeMaster> Code = null;
			try {
				Code = adminService.getGradeCodes();
			} catch (ClassNotFoundException | SQLException | IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			ArrayList <String> validateGradeCode=new ArrayList<String>();
			System.out.println("\n------------------");
			System.out.println("Grade Code");
			System.out.println("------------------");
			for(GradeMaster code:Code)
			{
				System.out.println(code.getGradeCode());
				validateGradeCode.add(code.getGradeCode());
			}
			System.out.println("------------------");
			System.out.println("Select Grade Code:");
			String eGradeCode;
			int eSal=0;
			do
			{
				eGradeCode=sc.next();
				eGradeCode=eGradeCode.toUpperCase();
				if(!adminService.isValidGradeCode(validateGradeCode,eGradeCode))
				{
					System.out.println("Selected GradeCode: "+eGradeCode+" is Invalid:\n \n");
					System.out.println("------------------");
					System.out.println("Grade Code");
					System.out.println("------------------");
					for(GradeMaster code:Code)
					{
						System.out.println(code.getGradeCode());
						validateGradeCode.add(code.getGradeCode());
					}
					System.out.println("------------------");
					System.out.println("Select Grade Code:");
				}
				else if(adminService.isValidGradeCode(validateGradeCode,eGradeCode))
				{
					int[] salBracket=new int[2];
					try {
						salBracket=adminService.salaryBracket(eGradeCode);
					} catch (ClassNotFoundException | SQLException | IOException e) {
						e.printStackTrace();
					}
					
					do
					{
						System.out.println("Enter Employee basic Salary in range:"+salBracket[0]+"-"+salBracket[1]);
						eSal=sc.nextInt();
						if(!adminService.isValidSalary(salBracket,eSal))
						{
							System.out.println("Entered Salary is not in Salary Brackets: ["+salBracket[0]+"-"+salBracket[1]+"]:\n \n ");
						}
					}while(!adminService.isValidSalary(salBracket,eSal));
				}
			}while(!adminService.isValidGradeCode(validateGradeCode,eGradeCode));
			
			
			String eDesig;
			do
			{
				System.out.println("Enter Employee Designation:");
				eDesig=sc.next();	
				if(!adminService.isValidDesignation(eDesig))
				{
					System.out.println("Designation Length cannot be greater than 15.");
				}
			}while(!adminService.isValidDesignation(eDesig));			
			
			int gen;
			String eGender=null;
			do
			{
				System.out.println("Select Gender:\n 1. Male \n 2. Female  \n 3. Other");
				gen=sc.nextInt();
				if(!adminService.isValidGender(gen))
				{
					System.out.println("Entered Gender in not valid:\n \n");
				}
				else if(adminService.isValidGender(gen))
				{
				
					switch(gen)
					{
					case 1: eGender="M";
					break;
					case 2: eGender="F";
					break;
					case 3: eGender="O";
					break;
					}
				}				
			}while(!adminService.isValidGender(gen));
			
			int status;
			String eMarStatus=null;
			do
			{
				System.out.println("Select Maritial Status:\n 1. Single\n 2. Married\n 3. Divorced\n 4. Seperated\n 5. Widowed");
				status=sc.nextInt();
				if(!adminService.isValidMaritialStatus(status))
				{
					System.out.println("Entered Maritial Status in not valid:\n \n");
				}
				else if(adminService.isValidMaritialStatus(status))
				{

					
					switch(status)
					{
					case 1: eMarStatus="S";
					break;
					case 2: eMarStatus="M";
					break;
					case 3: eMarStatus="D";
					break;
					case 4: eMarStatus="S";
					break;
					case 5: eMarStatus="W";
					break;
					}
				}
			}while(!adminService.isValidMaritialStatus(status));
			
			System.out.println("Enter Employee Address:");
			String eAddr=sc.next();
			
			long eContact;
			do
			{
				System.out.println("Enter Employee Contact Number:");
				eContact=sc.nextLong();
				if(!adminService.isValidContact(eContact))
				{
					System.out.println("Invalid contact number, should be 10 digits:\n \n");
				}
			}while(!adminService.isValidContact(eContact));
			
			String eMngID;
			ArrayList <String> validMngrId;
			do
			{
				System.out.println("Enter Employee Manager ID:");
				ArrayList<Employee> mngrList = adminService.getManagers();
				validMngrId = new ArrayList<String>();
				System.out.println("\n------------------");
				System.out.println("Managers Available");
				System.out.println("------------------");
				for(Employee emp : mngrList)
				{
					System.out.println(emp.getEmpID()+"\t"+emp.getEmpFirstName());
					validMngrId.add(emp.getEmpID());
				}
				System.out.println("------------------");
				System.out.println("Insert Manager Id:");
				eMngID=sc.next();

				if(!adminService.validateEmpId(eMngID))
				{
					System.out.println("Manager ID should be 6 digits");	
				}
			}while(!adminService.validateMngrId(validMngrId,eMngID));			
			Employee emp=new Employee(eId,eFName,eLName,eDOB,eDOJ,eDepId,eGradeCode,eDesig,eSal,eGender,eMarStatus,eAddr,eContact,eMngID);
			int iChoice1 = adminService.addEmployee(emp);
			int iChoice2 = adminService.addLogin(emp);
			if(iChoice1==1) {
				System.out.println("Inside 1st if");
				if(iChoice2==1) {
					System.out.println("Employee added Successfully");
					System.out.println("For Employee Login :");
					System.out.println("UserId will be the Employee Id and Password will be the First Name of the Employee in lowercase");
				}
			}
			else
			{
				System.out.println("Insert Operation failed");
			}
				
	}
	private static void modifyEmployee() {
		
		
	}
	private static void searchEmployee() {
		
		
	}
	private static void displayAllEmployees() throws ClassNotFoundException, EmployeeException, SQLException, IOException {
		ArrayList<Employee> emp = null;
			emp = adminService.displayAllEmployee();
			for(Employee e:emp)
			{
				System.out.println(e);
			}
		}
	private static void applyLeave(String userId) throws ClassNotFoundException, SQLException, IOException, EmployeeException {
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
		
		boolean leaveFlag=false;
		String fromDate=null;
		LocalDate fromLocalDate=null;
		do
		{
		System.out.println("Enter 'FROM' Date in format dd/MM/yyyy :");
		fromDate = sc.next();
		if(!adminService.isValidDateFormat(fromDate))
		{
			System.out.println("Date should be valid and should be in dd/MM/yyyy format");
			leaveFlag=false;
		}
		else if(adminService.isValidDateFormat(fromDate))
		{
			fromLocalDate = LocalDate.parse(fromDate, formatter);
			if(!adminService.isPastDateForLeave(fromLocalDate))
			{
				System.out.println("Leave for Past Dates cannot be applied");
				leaveFlag=false;
			}
			else if(adminService.isPastDateForLeave(fromLocalDate))
			{
				leaveFlag=true;
			}
		}
		}while(!leaveFlag);
		
		boolean toLeaveFlag=false;
		String toDate = null;
		LocalDate toLocalDate=null;
		do
		{
		System.out.println("Enter 'TO' Date in format dd/MM/yyyy :");
		toDate = sc.next();
		if(!adminService.isValidDateFormat(toDate))
		{
			System.out.println("Date should be valid and should be in dd/MM/yyyy format");
			toLeaveFlag=false;
		}
		else if(adminService.isValidDateFormat(toDate))
		{
			toLocalDate = LocalDate.parse(toDate, formatter);
			toLeaveFlag=true;
		}
		}while(!toLeaveFlag);
		empService = new EmployeeServiceImpl();
		
		int leaveDuration = ((int) ChronoUnit.DAYS.between(fromLocalDate, toLocalDate))+1;
		if(empService.findEmployeePastLeaves(userId)) {
			if(leaveDuration>0) {
				int leaveBudget = empService.fetchLeaveBudget(userId);
				if(leaveBudget-leaveDuration>=0) {
					LeaveRecords leaveRecord = new LeaveRecords();
					leaveRecord.setEmpId(userId);
					leaveRecord.setEmpName("Karan");
					leaveRecord.setFromDate(fromLocalDate);
					leaveRecord.setToDate(toLocalDate);
					leaveRecord.setNoOfDays(leaveDuration);
					leaveRecord.setLeaveBalance(leaveBudget-leaveDuration);
					leaveRecord.setStatus("applied");
					boolean requestStatus = empService.newLeaveRequest(leaveRecord);
					if(requestStatus) {
						System.out.println("Leave Applied Successfully");
					}
				}
				else {
					throw new EmployeeException("Leave Limit Exceeded");
				}
			}
			else {
				throw new EmployeeException("Dates are not in correct order");
			}
		}
		else {
			if(leaveDuration>0) {
				int leaveBudget = 12;
				if(leaveBudget-leaveDuration>=0) {
					LeaveRecords leaveRecord = new LeaveRecords();
					leaveRecord.setEmpId(userId);
					leaveRecord.setEmpName("Karan");
					leaveRecord.setFromDate(fromLocalDate);
					leaveRecord.setToDate(toLocalDate);
					leaveRecord.setNoOfDays(leaveDuration);
					leaveRecord.setLeaveBalance(leaveBudget-leaveDuration);
					leaveRecord.setStatus("applied");
					boolean requestStatus = empService.newLeaveRequest(leaveRecord);
					if(requestStatus) {
						System.out.println("Leave Applied Successfully");
					}
				}
				else {
					throw new EmployeeException("Leave Limit Exceeded");
				}
			}
			else {
				throw new EmployeeException("Dates are not in correct order");
			}
			
		}		
	}
	private static void previousLeave(String userId) throws ClassNotFoundException, SQLException, IOException, EmployeeException {
		ArrayList<LeaveRecords> previousLeaves = empService.fetchPreviousRequests(userId);
		for(LeaveRecords leaveObj : previousLeaves) {
			System.out.println(leaveObj);
		}
		
	}
	private static void leaveRequests(String userId) throws ClassNotFoundException, SQLException, IOException, EmployeeException {
		ArrayList<LeaveRecords> leaveRequests = empService.fetchAllLeaveRequests(userId); //here this will act as the managerId of the employees
		if(leaveRequests.isEmpty()) {
			System.out.println("No Pending Requests");
			return;
		}
		else {
			for(LeaveRecords leaveObj : leaveRequests) {
				System.out.println(leaveObj);
			}
			System.out.println();
			System.out.println("Enter the leaveId you want to modify :");
			int lId = sc.nextInt();
			//validation for leaveId
			System.out.println("Enter the Updated Status :");
			System.out.println("1-rejected");
			System.out.println("2-approved");
			int choice = sc.nextInt();
			String updatedStatus = null;
			if(choice == 1) {updatedStatus = "rejected";}
			else if(choice == 2) {updatedStatus = "approved";}
			else {System.out.println("Invalid Option");}
			boolean process = empService.updateLeaveRequest(lId,updatedStatus);
			if(process) {
				System.out.println("Leave Request Updated");
			}
			else {
				throw new EmployeeException("Leave Request not updated");
			}
			return;
		}
		
	}	
}
