package com.cg.ems.dto;

import java.time.LocalDate;

public class Employee {
	private String empID;
	private String empFirstName;
	private String empLastName;
	private LocalDate empDateofBirth;
	private LocalDate empDateofJoining;
	private Department dept;
	private String empGrade;
	private int empBasicSal;
	private String empGender;
	private String empMaritalStatus;
	private String empHomeAddress;
	private long empContactNum;
	private int mgrId;
	public Employee() {
		super();
	}
	public Employee(String empID, String empFirstName, String empLastName, LocalDate empDateofBirth,
			LocalDate empDateofJoining, Department dept, String empGrade, int empBasicSal, String empGender,
			String empMaritalStatus, String empHomeAddress, long empContactNum, int mgrId) {
		super();
		this.empID = empID;
		this.empFirstName = empFirstName;
		this.empLastName = empLastName;
		this.empDateofBirth = empDateofBirth;
		this.empDateofJoining = empDateofJoining;
		this.dept = dept;
		this.empGrade = empGrade;
		this.empBasicSal = empBasicSal;
		this.empGender = empGender;
		this.empMaritalStatus = empMaritalStatus;
		this.empHomeAddress = empHomeAddress;
		this.empContactNum = empContactNum;
		this.mgrId = mgrId;
	}
	public String getEmpID() {
		return empID;
	}
	public void setEmpID(String empID) {
		this.empID = empID;
	}
	public String getEmpFirstName() {
		return empFirstName;
	}
	public void setEmpFirstName(String empFirstName) {
		this.empFirstName = empFirstName;
	}
	public String getEmpLastName() {
		return empLastName;
	}
	public void setEmpLastName(String empLastName) {
		this.empLastName = empLastName;
	}
	public LocalDate getEmpDateofBirth() {
		return empDateofBirth;
	}
	public void setEmpDateofBirth(LocalDate empDateofBirth) {
		this.empDateofBirth = empDateofBirth;
	}
	public LocalDate getEmpDateofJoining() {
		return empDateofJoining;
	}
	public void setEmpDateofJoining(LocalDate empDateofJoining) {
		this.empDateofJoining = empDateofJoining;
	}
	public Department getDept() {
		return dept;
	}
	public void setDept(Department dept) {
		this.dept = dept;
	}
	public String getEmpGrade() {
		return empGrade;
	}
	public void setEmpGrade(String empGrade) {
		this.empGrade = empGrade;
	}
	public int getEmpBasicSal() {
		return empBasicSal;
	}
	public void setEmpBasicSal(int empBasicSal) {
		this.empBasicSal = empBasicSal;
	}
	public String getEmpGender() {
		return empGender;
	}
	public void setEmpGender(String empGender) {
		this.empGender = empGender;
	}
	public String getEmpMaritalStatus() {
		return empMaritalStatus;
	}
	public void setEmpMaritalStatus(String empMaritalStatus) {
		this.empMaritalStatus = empMaritalStatus;
	}
	public String getEmpHomeAddress() {
		return empHomeAddress;
	}
	public void setEmpHomeAddress(String empHomeAddress) {
		this.empHomeAddress = empHomeAddress;
	}
	public long getEmpContactNum() {
		return empContactNum;
	}
	public void setEmpContactNum(long empContactNum) {
		this.empContactNum = empContactNum;
	}
	public int getMgrId() {
		return mgrId;
	}
	public void setMgrId(int mgrId) {
		this.mgrId = mgrId;
	}
	@Override
	public String toString() {
		return "Employee [empID=" + empID + ", empFirstName=" + empFirstName + ", empLastName=" + empLastName
				+ ", empDateofBirth=" + empDateofBirth + ", empDateofJoining=" + empDateofJoining + ", dept=" + dept
				+ ", empGrade=" + empGrade + ", empBasicSal=" + empBasicSal + ", empGender=" + empGender
				+ ", empMaritalStatus=" + empMaritalStatus + ", empHomeAddress=" + empHomeAddress + ", empContactNum="
				+ empContactNum + ", mgrId=" + mgrId + "]";
	}
}
