package com.cg.ems.dto;

public class Department {
	private String empDesignation;
	private int empDeptID;
	public Department(String empDesignation, int empDeptID) {
		super();
		this.empDesignation = empDesignation;
		this.empDeptID = empDeptID;
	}
	public Department() {
		super();
	}
	public String getEmpDesignation() {
		return empDesignation;
	}
	public void setEmpDesignation(String empDesignation) {
		this.empDesignation = empDesignation;
	}
	public int getEmpDeptID() {
		return empDeptID;
	}
	public void setEmpDeptID(int empDeptID) {
		this.empDeptID = empDeptID;
	}
	@Override
	public String toString() {
		return "Department [empDesignation=" + empDesignation + ", empDeptID=" + empDeptID + "]";
	}
}
