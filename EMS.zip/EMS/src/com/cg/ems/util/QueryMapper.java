package com.cg.ems.util;

public interface QueryMapper {
	String EMP_fetchLeaveBudget_QRY = "SELECT leave_balance FROM Leave_History WHERE Emp_Id = ? ";
	String EMP_addLeaveRequest_QRY = "INSERT INTO Leave_History VALUES(leave_seq.NEXTVAL,?,?,?,?,?,?)";
	String EMP_fetchLeaveId_QRY = "SELECT leave_seq.CURRVAL FROM DUAL";
	String MGR_updateleaveStatus_QRY = "UPDATE Leave_History SET status = ? WHERE Leave_Id = ?";
	String MGR_fetchAllLeaveRequest_QRY = "SELECT * FROM Leave_History L WHERE L.status LIKE 'applied' AND Emp_id IN "
			+ "(SELECT E.EMP_ID FROM EMPLOYEE E WHERE E.Mgr_Id = ?)";
	String EMP_leavehistory_QRY = "SELECT * FROM Leave_History WHERE Emp_Id = ? ";
	String EMP_previousleavehistory_QRY = "SELECT * FROM Leave_History WHERE Emp_Id = ?";
	
	String EMP_loginDetails_QRY = "INSERT INTO User_Master VALUES(?,?,?,?)";
	String LOGIN_QRY = "SELECT * FROM User_Master WHERE UserId=? AND UserPassword=?";
	
	String EMP_INSERT_QRY = "INSERT INTO Employee VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
	String GET_EMP_SALARY_QRY = "SELECT Min_Salary,Max_Salary FROM Grade_Master WHERE GRADE_CODE=?";
	String GET_EMP_DEPARTMENT_QRY = "SELECT Dept_Name FROM Department WHERE Dept_Id=?";
	String GET_DEPARTMENT_QRY = "SELECT * FROM Department";
	String GET_GRADECODE_QRY = "SELECT * FROM Grade_Master";
	String GET_ALL_EMPLOYEE_QRY = "SELECT * FROM Employee";
	String GET_MANAGERS_QRY = "SELECT UserId, UserName FROM User_Master WHERE UserType LIKE 'Manager'";
	
}
