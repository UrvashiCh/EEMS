
package com.cg.ems.junit;
import com.cg.ems.junit.*;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;

import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.ems.service.AdminService;
import com.cg.ems.service.AdminServiceImpl;

public class ValidationTest 
{
	static AdminService adminServiceTest = null;
	
	@BeforeClass
	public static void setUp()
	{
		adminServiceTest = new AdminServiceImpl();
		System.out.println("This function is called before the execution of all test cases:");
	}
	
	/*******************************Salary Validation Test********************************************/
	@Test
	public void isValidateSalaryTest1()
	{
		int[] sal=new int[]{2000,3000};
		Assert.assertEquals(true,adminServiceTest.isValidSalary(sal, 2500));
	}
	@Test
	public void isValidateSalaryTest2()
	{
		int[] sal=new int[]{2000,3000};
		Assert.assertEquals(false,adminServiceTest.isValidSalary(sal, 3500));
	}
	
	/*******************************Employee ID Validation Test********************************************/
	@Test
	public void isValidateEmpIdTest1()
	{
		Assert.assertEquals(false,adminServiceTest.isValidateEmpId("1234"));
	}
	@Test
	public void isValidateEmpIdTest2()
	{
		Assert.assertEquals(false,adminServiceTest.isValidateEmpId("abc123"));
	}
	@Test
	public void isValidateEmpIdTest3()
	{
		Assert.assertEquals(true,adminServiceTest.isValidateEmpId("123456"));
	}
	
	@Test
	public void isValidateEmpIdTest4()
	{
		Assert.assertEquals(false,adminServiceTest.isValidateEmpId("123456345643"));
	}
	
	/*******************************Name Validation Test********************************************/
	@Test
	public void isValidateNameTest1()
	{
		Assert.assertEquals(false,adminServiceTest.isValidateName("shivendra", 1));
	}
	@Test
	public void isValidateNameTest2()
	{
		Assert.assertEquals(false,adminServiceTest.isValidateName("SHivendra", 1));
	}
	@Test
	public void isValidateNameTest3()
	{
		Assert.assertEquals(true,adminServiceTest.isValidateName("Shivendra", 1));
	}
	@Test
	public void isValidateNameTest4()
	{
		Assert.assertEquals(false,adminServiceTest.isValidateName("SHIVENDRA", 1));
	}
	@Test
	public void isValidateNameTest5()
	{
		Assert.assertEquals(false,adminServiceTest.isValidateName("sHIVENDRA", 1));
	}
	
	/*******************************Department Validation Test********************************************/

	@Test
	public void isValidateDeptIdTest1()
	{
		ArrayList<Integer> list=new ArrayList<Integer>(Arrays.asList(10,20,30,40,50));
		Assert.assertEquals(true,adminServiceTest.isValidateDeptID(list, 10));
	}
	@Test
	public void isValidateDeptIdTest2()
	{
		ArrayList<Integer> list=new ArrayList<Integer>(Arrays.asList(10,20,30,40,50));
		Assert.assertEquals(false,adminServiceTest.isValidateDeptID(list, 90));
	}
	
	/*******************************Grade Code Validation Test********************************************/
	@Test
	public void isValidGradeCodeTest1()
	{
		ArrayList<String> list=new ArrayList<String>(Arrays.asList("M1","M2","M3","M4","M5","M6","M7"));
		Assert.assertEquals(true,adminServiceTest.isValidGradeCode(list, "M1"));
	}
	@Test
	public void isValidGradeCodeTest2()
	{
		ArrayList<String> list=new ArrayList<String>(Arrays.asList("M1","M2","M3","M4","M5","M6","M7"));
		Assert.assertEquals(true,adminServiceTest.isValidGradeCode(list, "m3"));
	}
	@Test
	public void isValidGradeCodeTest3()
	{
		ArrayList<String> list=new ArrayList<String>(Arrays.asList("M1","M2","M3","M4","M5","M6","M7"));
		Assert.assertEquals(false,adminServiceTest.isValidGradeCode(list, "m9"));
	}
	
	/*******************************Gender Validation Test********************************************/
	@Test
	public void isValidGenderTest1()
	{
		Assert.assertEquals(true,adminServiceTest.isValidGender(1));
	}
	@Test
	public void isValidGenderTest2()
	{
		Assert.assertEquals(true,adminServiceTest.isValidGender(2));
	}
	@Test
	public void isValidGenderTest3()
	{
		Assert.assertEquals(true,adminServiceTest.isValidGender(3));
	}
	@Test
	public void isValidGenderTest4()
	{
		Assert.assertEquals(false,adminServiceTest.isValidGender(4));
	}
	
	/*******************************MaritialStatus Validation Test********************************************/
	@Test
	public void isValidMaritialStatusTest1()
	{
		Assert.assertEquals(true,adminServiceTest.isValidMaritialStatus(1));
	}
	@Test
	public void isValidMaritialStatusTest2()
	{
		Assert.assertEquals(true,adminServiceTest.isValidMaritialStatus(2));
	}
	@Test
	public void isValidMaritialStatusTest3()
	{
		Assert.assertEquals(true,adminServiceTest.isValidMaritialStatus(3));
	}
	@Test
	public void isValidMaritialStatusTest4()
	{
		Assert.assertEquals(true,adminServiceTest.isValidMaritialStatus(4));
	}
	@Test
	public void isValidMaritialStatusTest5()
	{
		Assert.assertEquals(true,adminServiceTest.isValidMaritialStatus(4));
	}
	@Test
	public void isValidMaritialStatusTest6()
	{
		Assert.assertEquals(false,adminServiceTest.isValidMaritialStatus(6));
	}
	
	/*******************************Contact Validation Test********************************************/
	@Test
	public void isValidContactTest1()
	{
		Assert.assertEquals(true,adminServiceTest.isValidContact(9876543211L));
	}
	@Test
	public void isValidContactTest2()
	{
		Assert.assertEquals(false,adminServiceTest.isValidContact(987653211L));
	}
	@Test
	public void isValidContactTest3()
	{
		Assert.assertEquals(false,adminServiceTest.isValidContact(5876532119L));
	}
	
	/*******************************Designation Validation Test********************************************/
	
	@Test
	public void isValidDesignationTest1()
	{
		Assert.assertEquals(true,adminServiceTest.isValidDesignation("Sr. Analyst"));
	}
	@Test
	public void isValidDesignationTest2()
	{
		Assert.assertEquals(false,adminServiceTest.isValidDesignation("Associate Consultant"));
	}
	
	/*******************************Date Format Validation Test********************************************/
	
	@Test
	public void isValidDateFormatTest1()
	{
		Assert.assertEquals(true,adminServiceTest.isValidDateFormat("12/12/2019"));
	}
	@Test
	public void isValidDateFormatTest2()
	{
		Assert.assertEquals(false,adminServiceTest.isValidDateFormat("12/13/2019"));
	}
	@Test
	public void isValidDateFormatTest3()
	{
		Assert.assertEquals(false,adminServiceTest.isValidDateFormat("32/02/2019"));
	}
	@Test
	public void isValidDateFormatTest4()
	{
		Assert.assertEquals(false,adminServiceTest.isValidDateFormat("12-12/2019"));
	}
	@Test
	public void isValidDateFormatTest5()
	{
		Assert.assertEquals(false,adminServiceTest.isValidDateFormat("12-12-2019"));
	}
	@Test
	public void isValidDateFormatTest6()
	{
		Assert.assertEquals(false,adminServiceTest.isValidDateFormat("31/14/2019"));
	}
	
	/*******************************DOB Validation Test********************************************/
	
	@Test
	public void isValidDOBTest1()
	{
		Assert.assertEquals(false,adminServiceTest.isValidDOB(LocalDate.of(2005, 1, 13)));
	}
	@Test
	public void isValidDOBTest2()
	{
	   
		Assert.assertEquals(true,adminServiceTest.isValidDOB(LocalDate.of(1996, 01, 25)));
	}
	
	/*******************************DOJ Validation Test********************************************/
	
	@Test
	public void isValidDOJTest1()
	{
		Assert.assertEquals(false,adminServiceTest.isValidDOJ(LocalDate.of(2005, 1, 13),LocalDate.of(2019, 1, 13)));
	}
	@Test
	public void isValidDOJTest2()
	{
	   
		Assert.assertEquals(true,adminServiceTest.isValidDOJ(LocalDate.of(1996, 01, 25),LocalDate.of(2019, 07, 11)));
	}
	
/*******************************Past Date Validation Test********************************************/
	
	@Test
	public void isValidPastDateForLeaveTest1()
	{
		Assert.assertEquals(false,adminServiceTest.isPastDateForLeave(LocalDate.of(2005, 1, 13)));
	}
	@Test
	public void isValidPastDateForLeaveTest2()
	{
	   
		Assert.assertEquals(false,adminServiceTest.isValidDOB(LocalDate.now()));
	}
	@Test
	public void isValidPastDateForLeaveTest3()
	{
	   
		Assert.assertEquals(false,adminServiceTest.isValidDOB(LocalDate.of(2019, 11, 13)));
	}
	
	/*******************************Manager ID Validation Test********************************************/
	@Test
	public void isValidMngrIdTest1()
	{
		ArrayList<String> list=new ArrayList<String>(Arrays.asList("123456","987654","898989"));
		Assert.assertEquals(true,adminServiceTest.isValidateMngrId(list, "123456"));
	}
	@Test
	public void isValidMngrIdTest2()
	{
		ArrayList<String> list=new ArrayList<String>(Arrays.asList("123456","987654","898989"));
		Assert.assertEquals(false,adminServiceTest.isValidateMngrId(list, "9876542"));
	}
	@Test
	public void isValidMngrIdTest3()
	{
		ArrayList<String> list=new ArrayList<String>(Arrays.asList("123456","987654","898989"));
		Assert.assertEquals(false,adminServiceTest.isValidateMngrId(list, "909098"));
	}
	
	/*******************************Department Validation Test********************************************/

	@Test
	public void isValidateLeaveIdTest1()
	{
		ArrayList<Integer> list=new ArrayList<Integer>(Arrays.asList(10,20,30,40,50));
		Assert.assertEquals(true,adminServiceTest.isValidateLeaveId(10,list));
	}
	@Test
	public void isValidateLeaveIdTest2()
	{
		ArrayList<Integer> list=new ArrayList<Integer>(Arrays.asList(10,20,30,40,50));
		Assert.assertEquals(false,adminServiceTest.isValidateLeaveId(90,list));
	}
	
/*******************************From-To Leave Date Validation Test********************************************/
	
	@Test
	public void isValidToDateTest1()
	{
		Assert.assertEquals(false,adminServiceTest.isValidtoDate(LocalDate.of(2005, 5, 14),LocalDate.of(2005, 5, 13)));
	}
	@Test
	public void isValidToDateTest2()
	{
	   
		Assert.assertEquals(true,adminServiceTest.isValidtoDate(LocalDate.of(2019, 07, 13),LocalDate.of(2019, 07, 13)));
	}
	
	
}
