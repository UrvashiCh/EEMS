package com.cg.ems.service;

import java.io.IOException;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;

import com.cg.ems.dto.Department;
import com.cg.ems.dto.Employee;
import com.cg.ems.dto.GradeMaster;
import com.cg.ems.exception.EmployeeException;

public interface AdminService 
{
	public int addEmployee(Employee emp)throws EmployeeException, ClassNotFoundException, SQLException, IOException;
	public int[] salaryBracket(String id) throws EmployeeException, ClassNotFoundException, SQLException, IOException;
	public String getDepartment(int id) throws EmployeeException, ClassNotFoundException, SQLException, IOException;
	public boolean validateSalary(int minSal,int maxSal,int selSal) throws EmployeeException;
	public boolean validateEmpId(String empId) throws EmployeeException;
	public boolean validateName(String empName,int flag) throws EmployeeException;
	public ArrayList<Department> displayDepartment()throws EmployeeException, ClassNotFoundException, SQLException, IOException;
	public ArrayList <GradeMaster> getGradeCodes()throws EmployeeException, ClassNotFoundException, SQLException, IOException;
	public boolean validateDeptID(ArrayList <Integer>validateDepId,int depId)throws EmployeeException;
	public boolean isValidGradeCode(ArrayList <String>validateGradeCode,String gradeCode)throws EmployeeException;
	public boolean isValidSalary(int[] salBracket,int eSal)throws EmployeeException;
	public boolean isValidGender(int gen)throws EmployeeException;
	public boolean isValidMaritialStatus(int status)throws EmployeeException;
	public boolean isValidContact(long contact) throws EmployeeException;
	public boolean isValidDesignation(String desig) throws EmployeeException;
	public boolean isValidDateFormat(String input) throws EmployeeException;
	public boolean isValidDOB(LocalDate date) throws EmployeeException;
	public boolean isValidDOJ(LocalDate date,LocalDate eDOJ) throws EmployeeException; 
	public boolean isPastDateForLeave(LocalDate date) throws EmployeeException;
	
	public boolean validateMngrId(ArrayList<String> validateDepId, String eMngID);
	public ArrayList <Employee> displayAllEmployee() throws EmployeeException, ClassNotFoundException, SQLException, IOException;
	public ArrayList<Employee> getManagers() throws ClassNotFoundException, SQLException, IOException;
	public int addLogin(Employee emp) throws ClassNotFoundException, SQLException, IOException;
}
