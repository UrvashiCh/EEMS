package com.cg.ems.service;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;

import com.cg.ems.dao.EmployeeDao;
import com.cg.ems.dao.EmployeeDaoImpl;
import com.cg.ems.dto.LeaveRecords;
import com.cg.ems.exception.EmployeeException;

public class EmployeeServiceImpl implements EmployeeService
{	EmployeeDao empDao = null;	
	public EmployeeServiceImpl() {
		empDao = new EmployeeDaoImpl();
	}

	@Override
	public int fetchLeaveBudget(String empId) throws ClassNotFoundException, SQLException, IOException {
		return empDao.fetchLeaveBudget(empId);
	}

	@Override
	public boolean newLeaveRequest(LeaveRecords leaveRecord) throws ClassNotFoundException, SQLException, IOException {
		return empDao.newLeaveRequest(leaveRecord);
	}

	@Override
	public boolean updateLeaveRequest(int lId, String updatedStatus) throws ClassNotFoundException, SQLException, IOException {
		return empDao.updateLeaveRequest(lId,updatedStatus);
	}

	@Override
	public ArrayList<LeaveRecords> fetchAllLeaveRequests(String empId) throws ClassNotFoundException, SQLException, IOException {
		return empDao.fetchAllLeaveRequests(empId);
	}

	@Override
	public boolean findEmployeePastLeaves(String empId) throws ClassNotFoundException, SQLException, IOException {
		return empDao.findEmployeePastLeaves(empId);
	}

	@Override
	public ArrayList<LeaveRecords> fetchPreviousRequests(String empId) throws ClassNotFoundException, SQLException, IOException, EmployeeException {
		return empDao.fetchPreviousRequests(empId);
	}
}
