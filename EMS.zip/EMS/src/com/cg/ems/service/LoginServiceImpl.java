package com.cg.ems.service;
import java.io.IOException;
import java.sql.SQLException;

import com.cg.ems.dao.LoginDao;
import com.cg.ems.dao.LoginDaoImpl;
import com.cg.ems.dto.UserMaster;
import com.cg.ems.exception.EmployeeException;

public class LoginServiceImpl implements LoginService {
	LoginDao loginDao;
  
	public LoginServiceImpl() throws ClassNotFoundException, SQLException, IOException{	
		loginDao = new LoginDaoImpl();
	}
	@Override
	public String EmployeeType(UserMaster um) throws SQLException, EmployeeException {	
		return loginDao.EmployeeType(um);
	}

}
