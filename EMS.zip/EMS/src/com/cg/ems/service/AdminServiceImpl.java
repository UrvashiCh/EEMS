package com.cg.ems.service;

public class AdminServiceImpl implements AdminService
{

}
