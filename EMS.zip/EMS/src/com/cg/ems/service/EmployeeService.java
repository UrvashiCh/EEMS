package com.cg.ems.service;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;

import com.cg.ems.dto.LeaveRecords;
import com.cg.ems.exception.EmployeeException;

public interface EmployeeService {
	public int fetchLeaveBudget(String empId) throws ClassNotFoundException, SQLException, IOException;
	public boolean newLeaveRequest(LeaveRecords leaveRecord) throws ClassNotFoundException, SQLException, IOException;
	public boolean updateLeaveRequest(int lId, String updatedStatus) throws ClassNotFoundException, SQLException, IOException;
	public ArrayList<LeaveRecords>fetchAllLeaveRequests(String empId) throws ClassNotFoundException, SQLException, IOException;
	public boolean findEmployeePastLeaves(String userId) throws ClassNotFoundException, SQLException, IOException;
	public ArrayList<LeaveRecords> fetchPreviousRequests(String userId) throws ClassNotFoundException, SQLException, IOException, EmployeeException;
}
