package com.cg.ems.dao;

import java.io.IOException;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import com.cg.ems.dto.Department;
import com.cg.ems.dto.Employee;
import com.cg.ems.dto.GradeMaster;
import com.cg.ems.exception.EmployeeException;
import com.cg.ems.util.DBUtil;
import com.cg.ems.util.QueryMapper;

public class AdminDaoImpl implements AdminDao{
	Connection con=null;
	Statement st=null;
	PreparedStatement pst=null;
	ResultSet rs=null;
	@Override
	public int addEmployee(Employee emp) throws EmployeeException, ClassNotFoundException, SQLException, IOException
	{
		con = DBUtil.getCon();
		int dataInserted=0;
		try 
		{
			pst=con.prepareStatement(QueryMapper.EMP_Insert_QRY);
			pst.setString(1, emp.getEmpID());
			pst.setString(2,emp.getEmpFirstName());
			pst.setString(3, emp.getEmpLastName());
			pst.setDate(4, Date.valueOf(emp.getEmpDateofBirth()));
			pst.setDate(5, Date.valueOf(emp.getEmpDateofJoining()));
			pst.setInt(6, emp.getEmpDeptID());
			pst.setString(7, emp.getEmpGrade());
			pst.setString(8, emp.getEmpDesignation());
			pst.setInt(9, emp.getEmpBasicSal());
			pst.setString(10, emp.getEmpGender());
			pst.setString(11, emp.getEmpMaritalStatus());
			pst.setString(12, emp.getEmpHomeAddress());
			pst.setLong(13, emp.getEmpContactNum());
			pst.setString(14, emp.getMgrId());			
			dataInserted=pst.executeUpdate();		
		} 
		catch (SQLException e) 
		{
			throw new EmployeeException(e.getMessage());
		}
		return dataInserted;
	}
	
	@Override
	public int addLogin(Employee emp) throws ClassNotFoundException, SQLException, IOException {
		con = DBUtil.getCon();
		pst = con.prepareStatement(QueryMapper.EMP_loginDetails_QRY);
		pst.setString(1, emp.getEmpID());
		pst.setString(2, emp.getEmpFirstName());
		pst.setString(3, emp.getEmpFirstName().toLowerCase());
		pst.setString(4, "Employee");
		int loginData = pst.executeUpdate();
		return loginData;
	}
	
	@Override
	public int[] salaryBracket(String id) throws EmployeeException, ClassNotFoundException, SQLException, IOException 
	{
		con = DBUtil.getCon();
		 int[] sal=new int[2];
		try
		{
			pst=con.prepareStatement(QueryMapper.GET_Salary_QRY);
			pst.setString(1, id);
			rs=pst.executeQuery();
			while(rs.next()) 
			{
				sal[0]=rs.getInt(1);
				sal[1]=rs.getInt(2);
			}
		}
		catch(SQLException e)
		{
			throw new EmployeeException(e.getMessage());
		}
		return sal;
	}

	@Override
	public String getDepartment(int id) throws EmployeeException, ClassNotFoundException, SQLException, IOException 
	{
		con = DBUtil.getCon();
		String empDepartment=null;
		try
		{
			pst=con.prepareStatement(QueryMapper.GET_DepartmentName_QRY);
			pst.setInt(1, id);
			rs=pst.executeQuery();
			while(rs.next()) 
			{
				empDepartment=rs.getString(1);
			}
		}
		catch(SQLException e)
		{
			throw new EmployeeException(e.getMessage());
		}
		return empDepartment;
	}
	@Override
	public ArrayList<Department> displayDepartment() throws EmployeeException, ClassNotFoundException, SQLException, IOException 
	{
		con = DBUtil.getCon();
		ArrayList<Department>departmentList=new ArrayList<Department>();
		try
		{
			st = con.createStatement();
			rs = st.executeQuery(QueryMapper.GET_Department_QRY);
			Department dept;
			while(rs.next())
			{
				dept=new Department(rs.getString(2),rs.getInt(1));
				departmentList.add(dept);
			}
		}
		catch(SQLException e)
		{
			throw new EmployeeException(e.getMessage());
		}
		return departmentList;
	}
	@Override
	public ArrayList<GradeMaster> getGradeCodes() throws EmployeeException, ClassNotFoundException, SQLException, IOException 
	{
		con = DBUtil.getCon();
		ArrayList<GradeMaster> grade=new ArrayList<GradeMaster>();
		try
		{
			pst=con.prepareStatement(QueryMapper.GET_GradeCode_QRY);
			rs=pst.executeQuery();
			GradeMaster details;
			while(rs.next())
			{
				details=new GradeMaster(rs.getString(1),rs.getInt(3),rs.getInt(4));
				grade.add(details);
			}
		}
		catch(SQLException e)
		{
			throw new EmployeeException(e.getMessage());
			
		}
		return grade;
	}
	@Override
	public ArrayList<Employee> displayAllEmployee() throws EmployeeException, ClassNotFoundException, SQLException, IOException 
	{
		con = DBUtil.getCon();
		ArrayList<Employee>list=new ArrayList<Employee>();
		try
		{
			st=con.createStatement();
			rs=st.executeQuery(QueryMapper.GET_AllEmployees_QRY);
			while(rs.next())
			{						
				Employee emp=new Employee(rs.getString(1),rs.getString(2),rs.getString(3),rs.getDate(4).toLocalDate(),
				rs.getDate(5).toLocalDate(),rs.getInt(6),rs.getString(7),rs.getString(8),
				rs.getInt(9),rs.getString(10),rs.getString(11),rs.getString(12),rs.getLong(13),rs.getString(14));
				list.add(emp);
			}
		}
		catch(SQLException e)
		{
			throw new EmployeeException(e.getMessage());
			
		}
		return list;
	}

	@Override
	public ArrayList<Employee> getManagers() throws ClassNotFoundException, SQLException, IOException {
		con = DBUtil.getCon();
		ArrayList<Employee>list=new ArrayList<Employee>();
		st = con.createStatement();
		rs=st.executeQuery(QueryMapper.GET_Managers_QRY);
		while(rs.next()) {
			Employee emp = new Employee();
			emp.setEmpID(rs.getString(1));
			emp.setEmpFirstName(rs.getString(2));
			list.add(emp);
		}
		return list;
	}

	@Override
	public String fetchEmpName(String empId) throws ClassNotFoundException, SQLException, IOException {
		con = DBUtil.getCon();
		pst = con.prepareStatement(QueryMapper.GET_EMPName_QRY);
		pst.setString(1, empId);
		rs = pst.executeQuery();
		String empName = null;
		while(rs.next()) {
			empName = rs.getString(1) + rs.getString(2);
		}
		return empName;
	}
}
