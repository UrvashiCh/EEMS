package com.cg.ems.dao;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;

import com.cg.ems.dto.Department;
import com.cg.ems.dto.Employee;
import com.cg.ems.dto.GradeMaster;
import com.cg.ems.exception.EmployeeException;

public interface AdminDao {
	public int addEmployee(Employee emp)throws EmployeeException, ClassNotFoundException, SQLException, IOException;
	public int[] salaryBracket(String id) throws EmployeeException, ClassNotFoundException, SQLException, IOException;
	public String getDepartment(int id) throws EmployeeException, ClassNotFoundException, SQLException, IOException;
	public ArrayList<Department> displayDepartment()throws EmployeeException, ClassNotFoundException, SQLException, IOException;
	public ArrayList <GradeMaster> getGradeCodes()throws EmployeeException, ClassNotFoundException, SQLException, IOException;
	public ArrayList <Employee> displayAllEmployee() throws EmployeeException, ClassNotFoundException, SQLException, IOException;
	public ArrayList<Employee> getManagers() throws ClassNotFoundException, SQLException, IOException;
	public int addLogin(Employee emp) throws ClassNotFoundException, SQLException, IOException;
	public String fetchEmpName(String empId) throws ClassNotFoundException, SQLException, IOException;
}
