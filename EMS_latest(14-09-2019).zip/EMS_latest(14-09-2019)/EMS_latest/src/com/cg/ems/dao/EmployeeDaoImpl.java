package com.cg.ems.dao;

import java.io.IOException;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.ArrayList;
import com.cg.ems.dto.Employee;
import com.cg.ems.dto.LeaveRecords;
import com.cg.ems.exception.EmployeeException;
import com.cg.ems.util.DBUtil;
import com.cg.ems.util.QueryMapper;

public class EmployeeDaoImpl implements EmployeeDao {
	Connection con = null;
	Statement st = null;
	PreparedStatement pst = null;
	ResultSet rs = null;
	@Override
	public int fetchLeaveBudget(int lId) throws ClassNotFoundException, SQLException, IOException {
		con = DBUtil.getCon();
		pst = con.prepareStatement(QueryMapper.EMP_fetchLeaveBudget_QRY);
		pst.setInt(1, lId);
		rs = pst.executeQuery();
		int result = 0;
		while(rs.next()) {
			result = rs.getInt(1);
		}
		return result;
	}
	
	@Override
	public int fetchLeaveDuration(int lId) throws ClassNotFoundException, SQLException, IOException {
		con = DBUtil.getCon();
		pst = con.prepareStatement(QueryMapper.EMP_fetchLeaveDuration_QRY);
		pst.setInt(1, lId);
		rs = pst.executeQuery();
		int result = 0;
		while(rs.next()) {
			result = rs.getInt(1);
		}
		return result;
	}

	@Override
	public int fetchInitialLeaveBudget(String empId) throws ClassNotFoundException, SQLException, IOException {
		con = DBUtil.getCon();
		pst = con.prepareStatement(QueryMapper.EMP_fetchInitialLeaveDuration_QRY);
		pst.setString(1, empId);
		rs = pst.executeQuery();
		int result = 0;
		while(rs.next()) {
			result = rs.getInt(1);
		}
		return result;
	}
	
	@Override
	public boolean newLeaveRequest(LeaveRecords leaveRecord) throws ClassNotFoundException, SQLException, IOException {
		con = DBUtil.getCon();
		pst = con.prepareStatement(QueryMapper.EMP_addLeaveRequest_QRY);
		pst.setString(1, leaveRecord.getEmpId());
		pst.setString(2, leaveRecord.getEmpName());
		pst.setInt(3, leaveRecord.getLeaveBalance());
		pst.setInt(4, leaveRecord.getNoOfDays());
		pst.setDate(5, Date.valueOf(leaveRecord.getFromDate()));
		pst.setDate(6, Date.valueOf(leaveRecord.getToDate()));
		pst.setString(7, leaveRecord.getStatus());
		int insertStatus = pst.executeUpdate();
		if(insertStatus>0){
			leaveRecord.setLeaveId(getLeaveId());
			return true;
		}
		return false;
	}

	private int getLeaveId() throws SQLException {
		int id=0;
		Statement stmt = con.createStatement();
		ResultSet rs = stmt.executeQuery(QueryMapper.EMP_fetchLeaveId_QRY);			
		if(rs.next()){
			id = rs.getInt(1);
		}
		return id;
	}

	@Override
	public boolean updateLeaveRequest(int lId, String updatedStatus, int leaveBal) throws SQLException, ClassNotFoundException, IOException {
		con = DBUtil.getCon();
		pst = con.prepareStatement(QueryMapper.MGR_updateleaveStatus_QRY);
		pst.setString(1, updatedStatus);
		pst.setInt(2, leaveBal);
		pst.setInt(3, lId);
		int updateStatus = pst.executeUpdate(); 
		if(updateStatus>0) {
			return true;
		}
		else {
			return false;
		}
	}

	@Override
	public ArrayList<LeaveRecords> fetchAllLeaveRequests(String mngrId) throws SQLException, ClassNotFoundException, IOException {
		con = DBUtil.getCon();
		pst = con.prepareStatement(QueryMapper.MGR_fetchAllLeaveRequest_QRY);
		pst.setString(1, mngrId);
		rs = pst.executeQuery();
		ArrayList<LeaveRecords> list = new ArrayList<LeaveRecords>();
		LeaveRecords lr = null;
		while(rs.next()) {
			lr = new LeaveRecords(); 
			lr.setLeaveId(rs.getInt(1));
			lr.setEmpId(rs.getString(2));
			lr.setEmpName(rs.getString(3));
			lr.setLeaveBalance(rs.getInt(4));
			lr.setNoOfDays(rs.getInt(5));
			lr.setFromDate(rs.getDate(6).toLocalDate());
			lr.setToDate(rs.getDate(7).toLocalDate());
			lr.setStatus(rs.getString(8));
			list.add(lr);
		}
		return list;
	}

	@Override
	public boolean findEmployeePastLeaves(String empId) throws ClassNotFoundException, SQLException, IOException {
		con = DBUtil.getCon();
		pst = con.prepareStatement(QueryMapper.EMP_leavehistory_QRY);
		pst.setString(1, empId);
		rs = pst.executeQuery();
		if(rs.next()) {
			return true;
		}
		else{
			return false;
		}
	}

	@Override
	public ArrayList<LeaveRecords> fetchPreviousRequests(String empId) throws ClassNotFoundException, SQLException, IOException, EmployeeException {
		ArrayList<LeaveRecords> list = null;
		try {
			con = DBUtil.getCon();
			pst = con.prepareStatement(QueryMapper.EMP_previousleavehistory_QRY);
			pst.setString(1, empId);
			rs = pst.executeQuery();
			list = new ArrayList<LeaveRecords>();
			LeaveRecords lr = null;
			while(rs.next()) {
				lr = new LeaveRecords(); 
				lr.setLeaveId(rs.getInt(1));
				lr.setEmpId(rs.getString(2));
				lr.setEmpName(rs.getString(3));
				lr.setLeaveBalance(rs.getInt(4));
				lr.setNoOfDays(rs.getInt(5));
				lr.setFromDate(rs.getDate(6).toLocalDate());
				lr.setToDate(rs.getDate(7).toLocalDate());
				lr.setStatus(rs.getString(8));
				list.add(lr);
			}
		} catch (Exception e) {
			throw new EmployeeException("Employee DAO Error");
		}
		return list;
	}

	@Override
	public Employee searchEmployeeById(String id) throws EmployeeException, ClassNotFoundException, SQLException, IOException {
		con = DBUtil.getCon();
		Employee emp = null;
		try {
			pst = con.prepareStatement(QueryMapper.SEARCH_Id_QRY);
			pst.setString(1,id);
			rs = pst.executeQuery();
			while(rs.next())
			{
				String id1=rs.getString(1);	
				String fn=rs.getString(2);
				String ln=rs.getString(3);
				LocalDate dob=rs.getDate(4).toLocalDate();
				LocalDate doj=rs.getDate(5).toLocalDate();
				int deptid=rs.getInt(6);
				String grade=rs.getString(7);
				String desg=rs.getString(8);
				int basic=rs.getInt(9);
				String gender=rs.getString(10);
				String marstatus=rs.getString(11);
				String addr=rs.getString(12);
				Long contactno=rs.getLong(13);
				String mgrid=rs.getString(14);
				emp = new Employee(id1,fn,ln,dob,doj,deptid,grade,desg,basic,gender,marstatus,addr,contactno,mgrid);
			}
		} catch (Exception e) {
			throw new EmployeeException("DAO Error");
		}
		return emp;
	}

	@Override
	public ArrayList<Employee> searchEmployeeByFirstName(String fn) throws EmployeeException, ClassNotFoundException, SQLException, IOException {
		con = DBUtil.getCon();
		Employee emp = null;
		ArrayList<Employee> list=new ArrayList<Employee>();
		try {
			pst = con.prepareStatement(QueryMapper.SEARCH_Fn_QRY);
			pst.setString(1,fn);
			rs = pst.executeQuery();
			while(rs.next())
			{
				String id1=rs.getString(1);	
				String fn1=rs.getString(2);
				String ln=rs.getString(3);
				LocalDate dob=rs.getDate(4).toLocalDate();
				LocalDate doj=rs.getDate(5).toLocalDate();
				int deptid=rs.getInt(6);
				String grade=rs.getString(7);
				String desg=rs.getString(8);
				int basic=rs.getInt(9);
				String gender=rs.getString(10);
				String marstatus=rs.getString(11);
				String addr=rs.getString(12);
				Long contactno=rs.getLong(13);
				String mgrid=rs.getString(14);
				emp = new Employee(id1,fn1,ln,dob,doj,deptid,grade,desg,basic,gender,marstatus,addr,contactno,mgrid);
				list.add(emp);
			}
		} catch (Exception e) {
			throw new EmployeeException("Employee DAO Error");
		}
		return list;
	}

	@Override
	public ArrayList<Employee> searchEmployeeByLastName(String ln) throws EmployeeException, ClassNotFoundException, SQLException, IOException {
		con = DBUtil.getCon();
		Employee emp = null;
		ArrayList<Employee> list=new ArrayList<Employee>();
		try {
			pst = con.prepareStatement(QueryMapper.SEARCH_Ln_QRY);
			pst.setString(1,ln);
			rs = pst.executeQuery();
			while(rs.next())
			{
				String id1=rs.getString(1);	
				String fn1=rs.getString(2);
				String ln1=rs.getString(3);
				LocalDate dob=rs.getDate(4).toLocalDate();
				LocalDate doj=rs.getDate(5).toLocalDate();
				int deptid=rs.getInt(6);
				String grade=rs.getString(7);
				String desg=rs.getString(8);
				int basic=rs.getInt(9);
				String gender=rs.getString(10);
				String marstatus=rs.getString(11);
				String addr=rs.getString(12);
				Long contactno=rs.getLong(13);
				String mgrid=rs.getString(14);
				emp = new Employee(id1,fn1,ln1,dob,doj,deptid,grade,desg,basic,gender,marstatus,addr,contactno,mgrid);
				list.add(emp);
			}
		} catch (Exception e) {
			throw new EmployeeException("Employee DAO Error");
		}
		return list;
	}

	@Override
	public ArrayList<Employee> searchEmployeeByDeptId(int id) throws EmployeeException, ClassNotFoundException, SQLException, IOException {
		con = DBUtil.getCon();
		Employee emp = null;
		ArrayList<Employee> list=new ArrayList<Employee>();
		try {
			pst = con.prepareStatement(QueryMapper.SEARCH_DepId_QRY);
			pst.setInt(1,id);
			rs=pst.executeQuery();
			while(rs.next())
			{
				String id1=rs.getString(1);	
				String fn1=rs.getString(2);
				String ln1=rs.getString(3);
				LocalDate dob=rs.getDate(4).toLocalDate();
				LocalDate doj=rs.getDate(5).toLocalDate();
				int deptid=rs.getInt(6);
				String grade=rs.getString(7);
				String desg=rs.getString(8);
				int basic=rs.getInt(9);
				String gender=rs.getString(10);
				String marstatus=rs.getString(11);
				String addr=rs.getString(12);
				Long contactno=rs.getLong(13);
				String mgrid=rs.getString(14);
				emp = new Employee(id1,fn1,ln1,dob,doj,deptid,grade,desg,basic,gender,marstatus,addr,contactno,mgrid);
				list.add(emp);
			}
		} catch (Exception e1) {
			throw new EmployeeException("Employee DAO Error");
		}
		return list;
	}

	@Override
	public ArrayList<Employee> searchEmployeeByGrade(String grade) throws EmployeeException, ClassNotFoundException, SQLException, IOException {
		con = DBUtil.getCon();
		Employee emp = null;
		ArrayList<Employee> list=new ArrayList<Employee>();
		try {
			pst = con.prepareStatement(QueryMapper.SEARCH_Grade_QRY);
			pst.setString(1,grade);
			rs = pst.executeQuery();
			while(rs.next())
			{
				String id1=rs.getString(1);	
				String fn1=rs.getString(2);
				String ln1=rs.getString(3);
				LocalDate dob=rs.getDate(4).toLocalDate();
				LocalDate doj=rs.getDate(5).toLocalDate();
				int deptid=rs.getInt(6);
				String grade1=rs.getString(7);
				String desg=rs.getString(8);
				int basic=rs.getInt(9);
				String gender=rs.getString(10);
				String marstatus=rs.getString(11);
				String addr=rs.getString(12);
				Long contactno=rs.getLong(13);
				String mgrid=rs.getString(14);
				emp = new Employee(id1,fn1,ln1,dob,doj,deptid,grade1,desg,basic,gender,marstatus,addr,contactno,mgrid);
				list.add(emp);
			}
		} catch (Exception e1) {
			throw new EmployeeException("Employee DAO Error");
		}
		return list;
	}

	@Override
	public ArrayList<Employee> searchEmployeeByMaritalStatus(String ms) throws ClassNotFoundException, SQLException, IOException, EmployeeException {
		con = DBUtil.getCon();
		Employee emp = null;
		ArrayList<Employee> list=new ArrayList<Employee>();
		try {
			pst = con.prepareStatement(QueryMapper.SEARCH_MS_QRY);
			pst.setString(1,ms);
			rs = pst.executeQuery();
			while(rs.next())
			{
				String id1=rs.getString(1);	
				String fn1=rs.getString(2);
				String ln1=rs.getString(3);
				LocalDate dob=rs.getDate(4).toLocalDate();
				LocalDate doj=rs.getDate(5).toLocalDate();
				int deptid=rs.getInt(6);
				String grade1=rs.getString(7);
				String desg=rs.getString(8);
				int basic=rs.getInt(9);
				String gender=rs.getString(10);
				String marstatus=rs.getString(11);
				String addr=rs.getString(12);
				Long contactno=rs.getLong(13);
				String mgrid=rs.getString(14);
				emp = new Employee(id1,fn1,ln1,dob,doj,deptid,grade1,desg,basic,gender,marstatus,addr,contactno,mgrid);
				list.add(emp);
			}
		} catch (Exception e1) {
			throw new EmployeeException("Employee DAO Error");
		}
		return list;
	}

}
