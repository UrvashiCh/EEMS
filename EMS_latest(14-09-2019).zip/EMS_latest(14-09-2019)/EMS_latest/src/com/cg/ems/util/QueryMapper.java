package com.cg.ems.util;

public interface QueryMapper {
	String EMP_fetchInitialLeaveDuration_QRY = "SELECT leave_balance FROM Leave_History WHERE Emp_Id = ?";
	String EMP_fetchLeaveBudget_QRY = "SELECT leave_balance FROM Leave_History WHERE Leave_Id = ? ";
	String EMP_fetchLeaveDuration_QRY = "SELECT NoofDays_Applied FROM Leave_History WHERE Leave_Id = ?";
	String EMP_addLeaveRequest_QRY = "INSERT INTO Leave_History VALUES(leave_seq.NEXTVAL,?,?,?,?,?,?,?)";
	String EMP_fetchLeaveId_QRY = "SELECT leave_seq.CURRVAL FROM DUAL";
	String MGR_updateleaveStatus_QRY = "UPDATE Leave_History SET status = ?, Leave_Balance = ? WHERE Leave_Id = ?";
	String MGR_fetchAllLeaveRequest_QRY = "SELECT * FROM Leave_History L WHERE L.status LIKE 'applied' AND Emp_id IN "
			+ "(SELECT E.EMP_ID FROM EMPLOYEE E WHERE E.Mgr_Id = ?)";
	String EMP_leavehistory_QRY = "SELECT * FROM Leave_History WHERE Emp_Id = ? ";
	String EMP_previousleavehistory_QRY = "SELECT * FROM Leave_History WHERE Emp_Id = ?";
	
	String EMP_loginDetails_QRY = "INSERT INTO User_Master VALUES(?,?,?,?)";
	String LOGIN_QRY = "SELECT * FROM User_Master WHERE UserId=? AND UserPassword=?";
	
	String EMP_Insert_QRY = "INSERT INTO Employee VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
	String GET_Salary_QRY = "SELECT Min_Salary,Max_Salary FROM Grade_Master WHERE GRADE_CODE=?";
	String GET_DepartmentName_QRY = "SELECT Dept_Name FROM Department WHERE Dept_Id=?";
	String GET_Department_QRY = "SELECT * FROM Department";
	String GET_GradeCode_QRY = "SELECT * FROM Grade_Master";
	String GET_AllEmployees_QRY = "SELECT * FROM Employee";
	String GET_Managers_QRY = "SELECT UserId, UserName FROM User_Master WHERE UserType LIKE 'Manager'";
	String GET_EMPName_QRY = "SELECT EMP_FIRST_NAME,EMP_LAST_NAME FROM Employee WHERE EMP_ID = ?";
	
	
	String SEARCH_Id_QRY = "SELECT * FROM Employee WHERE Emp_Id = ?";
	String SEARCH_Fn_QRY = "SELECT * FROM Employee WHERE Emp_First_Name = ?";
	String SEARCH_Ln_QRY = "SELECT * FROM Employee WHERE Emp_Last_Name = ?";
	String SEARCH_DepId_QRY = "SELECT * FROM Employee WHERE Emp_Dept_ID = ?";
	String SEARCH_Grade_QRY = "SELECT * FROM Employee WHERE Emp_Grade = ?";
	String SEARCH_MS_QRY = "SELECT * FROM Employee WHERE Emp_Marital_Status  = ?";
	
	
	
	
}
