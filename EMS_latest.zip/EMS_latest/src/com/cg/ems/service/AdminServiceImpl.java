//This is the implementation of the AdminService interface. The methods are overridden to interact with the DAO layer and return appropriate results.

package com.cg.ems.service;

import java.io.IOException;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.regex.Pattern;
import com.cg.ems.dao.AdminDao;
import com.cg.ems.dao.AdminDaoImpl;
import com.cg.ems.dto.Department;
import com.cg.ems.dto.Employee;
import com.cg.ems.dto.GradeMaster;
import com.cg.ems.dto.LeaveRecords;
import com.cg.ems.exception.EmployeeException;

/*
 * In the class AdminServiceImpl, a AdminDao object is created which is instantiated with AdminDaoImpl.
 * This object is used to fetch result from the DAO operation and return it to the UI.
 */
public class AdminServiceImpl implements AdminService
{
	AdminDao adminDao;
	public AdminServiceImpl() {
		adminDao = new AdminDaoImpl();
	}
	
	/**
	 * 
	 * Return 1 if the Employee details are added successfully.
	
	 * @param emp 
	 * 				Object of Employee class
	
	 * @return whether or not the Employee details are added in the database
	 * 
	 **/
	@Override
	public int addEmployee(Employee emp) throws EmployeeException, ClassNotFoundException, SQLException, IOException {
		return adminDao.addEmployee(emp);
	}

	/**
	 * 
	 * Return the department name as a string.
	
	 * @param id
	 * 				ID of the department, whose name to fetch.
	
	 * @return name of the department according to id.
	 * 
	 **/
	@Override
	public String getDepartment(int id) throws EmployeeException, ClassNotFoundException, SQLException, IOException {
		return adminDao.getDepartment(id);
	}
	
	/**
	 * 
	 * Return the salary bracket.
	 
	 * @param id
	 * 				ID, whose salary bracket to fetch.
	 
	 * @return Salary bracket as an array.
	 * 
	 **/
	@Override
	public int[] salaryBracket(String id) throws EmployeeException, ClassNotFoundException, SQLException, IOException {
		return adminDao.salaryBracket(id);
	}

	/**
	 * 
	 * Return the ArrayList of department object.
	 * 
	 */
	@Override
	public ArrayList<Department> displayDepartment()throws EmployeeException, ClassNotFoundException, SQLException, IOException {
		return adminDao.displayDepartment();
	}

	/**
	 * 
	 * Return the ArrayList of GradeMaster object.
	 * 
	 */
	@Override
	public ArrayList<GradeMaster> getGradeCodes() throws EmployeeException, ClassNotFoundException, SQLException, IOException {
		return adminDao.getGradeCodes();
	}

	/**
	 * 
	 * Return the ArrayList of Employee object.
	 * 
	 */
	@Override
	public ArrayList<Employee> displayAllEmployee() throws EmployeeException, ClassNotFoundException, SQLException, IOException {
		return adminDao.displayAllEmployee();
	}

	/**
	 * 
	 * Return the ArrayList of Manager object.
	 * 
	 */
	@Override
	public ArrayList<Employee> getManagers(int eDeptID) throws ClassNotFoundException, SQLException, IOException {
		return adminDao.getManagers(eDeptID);
	}
	/**
	 * add the login details of new users.
	 * @param emp
	 * Employee object.
	 * @return status of updation.
	 **/
	@Override
	public int addLogin(Employee emp) throws ClassNotFoundException, SQLException, IOException {
		return adminDao.addLogin(emp);
	}
	/**
	 * add the login details of new users.
	 * @param id
	 * ID of the employee, whose fields needs to be updated.
	 * @return Employee Name according to Employee Id
	 **/
	@Override
	public String fetchEmpName(String empId) throws ClassNotFoundException, SQLException, IOException {
		return adminDao.fetchEmpName(empId);
	}
	/**
	 * Get the Employee by id
	 * @param id
	 * ID of the employee, whose fields needs to be updated.
	 * @return Employee Object
	 **/
	@Override
	public Employee getEmployeeById(String id) throws EmployeeException {
		return adminDao.getEmployeeById(id);
	}
	/**
	 * updates the fields of employee based on id.
	 * @param id
	 * ID of the employee, whose fields needs to be updated.
	 * @return updated fields according to id.
	 *
	 **/
	@Override
	public int updateEmployee(Employee emp) throws EmployeeException {
		return adminDao.updateEmployee(emp);
	}

	/**
	 * 
	 * Return true if the String is 6 digit numeric only.
	 *
	 * 
	 * 
	 * @param empId
	 * Employee Id to be validated
	 *
	 * 
	 * 
	 * @return whether or not the employee ID is valid
	 * 
	 **/
	@Override
	public boolean isValidateEmpId(String empId)
	{
		String empIdPattern = "[0-9]{6}";
		if (Pattern.matches(empIdPattern, empId))
		{
			return true;
		}
		else
		{
			return false;
		}
	}

	/**
	 * 
	 * Return true if the contact is valid 10 digit phone number.
	 *
	 * 
	 * 
	 * @param contact
	 * The parameter to be validated.
	 * 
	 * @return whether or not the contact is valid
	 * 
	 **/
	@Override
	public boolean isValidContact(long contact)
	{
		String matchPattern = "[6-9]{1}[0-9]{9}";
		String contactPattern = Long.toString(contact);
		if (Pattern.matches(matchPattern, contactPattern))
		{
			return true;
		}
		else
		{
			return false;
		}
	}

	/**
	 * 
	 * Return true if the Employee Name starts with a capital letter.
	 *
	 * 
	 * 
	 * @param empName
	 * The parameter to be validated.
	 * 
	 * @return whether or not the empName is valid.
	 * 
	 **/
	@Override
	public boolean isValidateName(String empName)
	{
		String empNamePattern = "[A-Z][a-z]+";
		if (Pattern.matches(empNamePattern, empName))
		{
			return true;
		}
		else
		{
			return false;
		}
	}

	/**
	 * 
	 * Return true if the Department ID is present.
	 *
	 * 
	 * 
	 * @param validateDepId
	 * 
	 *                      The ArrayList of Integer containing all the Department
	 *                      IDs to be matched from.
	 * 
	 * @param depId
	 * 
	 *                      The department ID to be checked
	 *
	 * 
	 * 
	 * @return whether or not the department ID is present in the ArrayList.
	 * 
	 **/
	@Override
	public boolean isValidateDeptID(ArrayList<Integer> validateDepId, int depId)
	{
		if (validateDepId.contains(depId))
		{
			return true;
		}
		else
		{
			return false;
		}
	}

	/**
	 * 
	 * Return true if the Manager ID is valid and present in the ArrayList.
	 *
	 * 
	 * 
	 * @param validateMgrId
	 * 
	 *                      The ArrayList of String containing all the Manager IDs
	 *                      to be matched from.
	 * 
	 * @param eMngID
	 * 
	 *                      The Manager ID to be validated and checked for
	 *
	 * 
	 * 
	 * @return whether or not the Manager ID is present in the ArrayList.
	 * 
	 **/
	@Override
	public boolean isValidateMngrId(ArrayList<String> validateMgrId, String eMngID) {
		String empIdPattern = "[0-9]{6}";
		if (validateMgrId.contains(eMngID) && Pattern.matches(empIdPattern, eMngID)) {
			return true;
		}
		else {
			System.out.println("Manager not Recognised. Please Select from list");
			return false;
		}
	}

	/**
	 * 
	 * Return true if the gradeCode is valid.
	 *
	 * 
	 * 
	 * @param validateGradeCode
	 * 
	 *                          The ArrayList of String containing all the
	 *                          GradeCodes to be matched from.
	 * 
	 * @param gradeCode
	 * 
	 *                          The Grade Code to be checked for
	 *
	 * 
	 * 
	 * @return whether or not the gradeCode is present in the ArrayList.
	 * 
	 **/
	@Override
	public boolean isValidGradeCode(ArrayList<String> validateGradeCode, String gradeCode)
	{
		gradeCode = gradeCode.toUpperCase();
		if (validateGradeCode.contains(gradeCode))
		{
			return true;
		}
		else
		{
			return false;
		}
	}

	/**
	 * 
	 * Return true if the Employee Salary is in the salary brackets.
	 *
	 * 
	 * 
	 * @param salBracket
	 * 
	 *                   The Array containing the minimum and maximum salary an
	 *                   Employee can have.
	 * 
	 * @param eSal
	 * 
	 *                   The Salary of the Employee
	 *
	 * 
	 * 
	 * @return whether or not the eSal is in salBracket.
	 * 
	 **/
	@Override
	public boolean isValidSalary(int[] salBracket, int eSal)
	{
		if (salBracket[1] >= eSal && salBracket[0] <= eSal)
		{
			return true;
		}
		else
		{
			return false;
		}
	}

	/**
	 * 
	 * Return true if the Gender Code is valid.
	 *
	 * 
	 * 
	 * @param gen
	 * 
	 *            The parameter to be validated.
	 * 
	 * @return whether or not the gen is valid gender code.
	 * 
	 **/
	@Override
	public boolean isValidGender(int gen)
	{
		if (gen <= 3 && gen >= 1)
		{
			return true;
		}
		else
		{
			return false;
		}
	}

	/**
	 * 
	 * Return true if the Marital Status Code is valid.
	 *
	 * 
	 * 
	 * @param status
	 * 
	 *               The parameter to be validated.
	 * 
	 * @return whether or not the status is valid Marital Status Code.
	 * 
	 **/
	@Override
	public boolean isValidMaritialStatus(int status)
	{
		if (status <= 5 && status >= 1)
		{
			return true;
		}
		else
		{
			return false;
		}
	}

	/**
	 * 
	 * Return true if the Designation is less than 16 characters.
	 *
	 * 
	 * 
	 * @param desig
	 * 
	 *              The parameter to be validated.
	 * 
	 * @return whether or not the desig is valid.
	 * 
	 **/
	@Override
	public boolean isValidDesignation(String desig)
	{
		if (desig.length() > 15)
		{
			return false;
		}
		else
		{
			return true;
		}
	}

	/**
	 * 
	 * Return true if the date is a valid date and is in (dd/MM/yyyy) format.
	 *
	 * 
	 * 
	 * @param input
	 * 
	 *              The parameter to be validated.
	 * 
	 * @return whether or not the date is valid and in proper format.
	 * 
	 **/
	@Override
	public boolean isValidDateFormat(String input)
	{
		try
		{
			DateTimeFormatter format = DateTimeFormatter.ofPattern("dd/MM/yyyy");
			LocalDate date = LocalDate.parse(input, format);
		}
		catch (DateTimeParseException e)
		{
			return false;
		}
		return true;
	}

	/**
	 * 
	 * Return true if the difference between current date and entered date is at
	 * least 20 years.
	 *
	 * 
	 * 
	 * @param date
	 * 
	 *             The parameter to be validated.
	 * 
	 * @return whether or not the date and current date at least 20 years apart.
	 * 
	 **/
	@Override
	public boolean isValidDOB(LocalDate date)
	{
		LocalDate today = LocalDate.now();
		Period diff = date.until(today);
		if (diff.getYears() < 20)
		{
			return false;
		}
		else
		{
			return true;
		}
	}

	/**
	 * 
	 * Return true if the difference between date(Employee Date of Birth) and eDOJ
	 * (Employee Date of Joining) is at least 20 years.
	 *
	 * 
	 * 
	 * @param date
	 * 
	 *             The parameter containing Employee date of birth.
	 * 
	 * @param eDOJ
	 * 
	 *             The Employee DOJ that is to be validated
	 *
	 * 
	 * 
	 * @return whether or not the date and eDOJ at least 20 years apart.
	 * 
	 **/
	@Override
	public boolean isValidDOJ(LocalDate date, LocalDate eDOJ)
	{
		Period diff = date.until(eDOJ);
		if (diff.getYears() < 20)
		{
			return false;
		}
		else
		{
			return true;
		}
	}

	/**
	 * 
	 * Return true if the date for which leave is applied is not a past date.
	 *
	 * 
	 * 
	 * @param date
	 * 
	 *             The parameter to be validated.
	 * 
	 * @return whether or not the date is a past date.
	 * 
	 **/
	@Override
	public boolean isPastDateForLeave(LocalDate date)
	{
		LocalDate today = LocalDate.now();
		Period diff = date.until(today);
		// remove =0, if want to apply the leave of current date also
		if (diff.getYears() > 0 || diff.getMonths() > 0 || diff.getDays() >= 0)
		{
			return false;
		}
		else
		{	
			return true;
		}
	}
	/**
	 * 
	 * Return true if the Leave ID is present.
	 *
	 * 
	 * 
	 * @param leaveIdList
	 * 
	 *                    The ArrayList of Integer containing all the Leave IDs to
	 *                    be matched from.
	 * 
	 * @param lId
	 * 
	 *                    The leave ID to be checked
	 *
	 * 
	 * 
	 * @return whether or not the leave ID is present in the ArrayList.
	 * 
	 **/
	@Override
	public boolean isValidateLeaveId(int lId, ArrayList<Integer> leaveIdList) {
		if (leaveIdList.contains(lId)) {
			return true;
		}
		else {
			return false;
		}
	}

	/**
	 * 
	 * Return true if the to and from leave date are valid.
	 *
	 * 
	 * 
	 * @param fromLocalDate
	 * 
	 *                      The parameter having leave starting date.
	 * 
	 * @param toLocalDate
	 * 
	 *                      The parameter having leave end date.
	 *
	 * 
	 * 
	 * @return whether or not the from and to date in order.
	 * 
	 **/
	@Override
	public boolean isValidtoDate(LocalDate fromLocalDate, LocalDate toLocalDate) {
		Period diff = fromLocalDate.until(toLocalDate);
		if (diff.getDays() < 0 || diff.getMonths() < 0 || diff.getYears() < 0)
		{
			return false;
		}
		else
		{
			return true;
		}
	}

	@Override
	public boolean isValidLeavedate(LocalDate Date, ArrayList<LeaveRecords> list, int i) {
		if(i==1) {
			for(LeaveRecords lr: list) {
				int flag = Date.compareTo(lr.getFromDate())*Date.compareTo(lr.getToDate());
				if(flag<0) {
					return false;
				}
				else if(flag>0) {
					continue;
				}
				else {
					return false;
				}
			}
		}
		else if(i==2) {
			for(LeaveRecords lr: list) {
				int flag = Date.compareTo(lr.getFromDate())*Date.compareTo(lr.getToDate());
				if(flag<0) {
					return false;
				}
				else if(flag>0) {
					continue;
				}
				else {
					return false;
				}
			}
		}
		return true;
	}
	@Override
	public boolean isValidFinalLeavedate(LocalDate toLocalDate, LocalDate fromLocalDate, ArrayList<LeaveRecords> list) {
			for(LeaveRecords lr: list) {
				int flag1 = lr.getFromDate().compareTo(toLocalDate)*lr.getFromDate().compareTo(fromLocalDate);
				int flag2 = lr.getToDate().compareTo(toLocalDate)*lr.getToDate().compareTo(fromLocalDate);
				if(flag1<0 || flag2<0) {
					return false;
				}
				else if(flag1>0 && flag2>0) {
					continue;
				}
				else {
					return false;
				}
			}
		return true;
	}
	
	
}
