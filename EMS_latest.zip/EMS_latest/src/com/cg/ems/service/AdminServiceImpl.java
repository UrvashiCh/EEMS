package com.cg.ems.service;

import java.io.IOException;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.regex.Pattern;
import com.cg.ems.dao.AdminDao;
import com.cg.ems.dao.AdminDaoImpl;
import com.cg.ems.dto.Department;
import com.cg.ems.dto.Employee;
import com.cg.ems.dto.GradeMaster;
import com.cg.ems.exception.EmployeeException;

public class AdminServiceImpl implements AdminService
{
AdminDao adminDao;
	
	public AdminServiceImpl(){
		adminDao =new AdminDaoImpl();
	}

	@Override
	public int addEmployee(Employee emp) throws EmployeeException, ClassNotFoundException, SQLException, IOException{
		return adminDao.addEmployee(emp);
	}

	@Override
	public String getDepartment(int id) throws EmployeeException, ClassNotFoundException, SQLException, IOException {
		return adminDao.getDepartment(id);
	}

	@Override
	public int[] salaryBracket(String id) throws EmployeeException, ClassNotFoundException, SQLException, IOException {
		return adminDao.salaryBracket(id);
	}

	@Override
	public ArrayList<Department> displayDepartment() throws EmployeeException, ClassNotFoundException, SQLException, IOException{
		return adminDao.displayDepartment();
	}

	@Override
	public ArrayList<GradeMaster> getGradeCodes() throws EmployeeException, ClassNotFoundException, SQLException, IOException{
		return adminDao.getGradeCodes();
	}
	
	@Override
	public ArrayList<Employee> displayAllEmployee() throws EmployeeException, ClassNotFoundException, SQLException, IOException{
		return adminDao.displayAllEmployee();
	}
	
	@Override
	public ArrayList<Employee> getManagers() throws ClassNotFoundException, SQLException, IOException {
		return adminDao.getManagers();
	}
	
	@Override
	public int addLogin(Employee emp) throws ClassNotFoundException, SQLException, IOException {
		return adminDao.addLogin(emp);
	}
	
	@Override
	public String fetchEmpName(String empId) throws ClassNotFoundException, SQLException, IOException {
		return adminDao.fetchEmpName(empId);
	}

	@Override
	public Employee getEmployeeById(String id) throws EmployeeException {
		return adminDao.getEmployeeById(id);
	}
	
	@Override
	public int updateEmployee(Employee emp) throws EmployeeException {
		return adminDao.updateEmployee(emp);
	}
	/*
	@Override
	public boolean isValidateSalary(int minSal, int maxSal, int selSal) throws EmployeeException 
	{
		if(selSal>=minSal && selSal<=maxSal)
		{
			return true;
		}
		else
		{
			return false;
			//throw new EmployeeException("Salary should be within "+minSal+" - "+maxSal+" bracket");
		}
		
	}*/
	@Override
	public boolean isValidateEmpId(String empId) 
	{
		String empIdPattern="[0-9]{6}";
		if(Pattern.matches( empIdPattern,empId))
		{
			return true;
		}
		else
		{
			//throw new EmployeeException("Invalid Employee ID, should have only 6 digits:\n\n\n");
			return false;
		}
	}
	
	@Override
	public boolean isValidContact(long contact)
	{
		String matchPattern="[6-9]{1}[0-9]{9}";
		String contactPattern=Long.toString(contact);
		if(Pattern.matches(matchPattern, contactPattern))
		{
			return true;
		}
		else
		{
			return false;
			//throw new EmployeeException("Invalid contact number, should be 10 digits:\n\n\n");
		}
	}

	@Override
	public boolean isValidateName(String empName,int flag)
	{
		
		String empNamePattern="[A-Z][a-z]+";
		if(Pattern.matches(empNamePattern,empName))
		{
			return true;
		}
		else
		{
			return false;
			/*
			if(flag==1)
			{
				throw new EmployeeException("Invalid First Name, Should start with Capital:\n\n\n");
				
			}
			else
			{
				throw new EmployeeException("Invalid Last Name, Should start with Capital:\n\n\n");
				
			}
			*/
		}
	}
	@Override
	public boolean isValidateDeptID(ArrayList<Integer> validateDepId, int depId)
	{
		if(validateDepId.contains(depId))
		{
			return true;
		}
		else
		{
			return false;
			//throw new EmployeeException("Selected Department ID: "+depId+" is Invalid:\n\n\n");
		}		
	}
	@Override
	public boolean isValidateMngrId(ArrayList<String> validateDepId, String eMngID) {
		String empIdPattern="[0-9]{6}";
		if(validateDepId.contains(eMngID) && Pattern.matches(empIdPattern,eMngID)) {
			return true;
		}
		else {
			System.out.println("Manager not Recognised. Please Select from list");
			return false;
		}
	}
	@Override
	public boolean isValidGradeCode(ArrayList<String> validateGradeCode, String gradeCode)
	{
		gradeCode=gradeCode.toUpperCase();
		if(validateGradeCode.contains(gradeCode))
		{
			return true;
		}
		else
		{
			return false;
			//throw new EmployeeException("Selected GradeCode: "+gradeCode+" is Invalid:\n\n\n");
		}
		
	}

	@Override
	public boolean isValidSalary(int[] salBracket, int eSal)
	{
		if(salBracket[1]>=eSal && salBracket[0]<=eSal)
		{
			return true;
		}
		else
		{
			return false;
			//throw new EmployeeException("Entered Salary is not in Salary Brackets: ["+salBracket[0]+"-"+salBracket[1]+"]:\n\n\n");
		}
	}

	@Override
	public boolean isValidGender(int gen)
	{
		if(gen<=3 && gen>=1)
		{
			return true;
		}
		else
		{
			return false;
			//throw new EmployeeException("Entered Gender in not valid:\n\n\n");
		}
		
	}

	@Override
	public boolean isValidMaritialStatus(int status)
	{
		if(status<=5 && status>=1)
		{
			return true;
		}
		else
		{
			return false;
			//throw new EmployeeException("Entered Maritial Status in not valid:\n\n\n");
		}
	}

	@Override
	public boolean isValidDesignation(String desig)
	{
		if(desig.length()>15)
		{
			return false;
		}
		else
		{
			return true;
		}
	}

	@Override
	public boolean isValidDateFormat(String input)
	{
		//System.out.println("the date is ---------------------");
		try
		{
			DateTimeFormatter format=DateTimeFormatter.ofPattern("dd/MM/yyyy");
			LocalDate date=LocalDate.parse(input,format);
			//System.out.println("the date is "+date+" ---------------------");
		}
		catch(DateTimeParseException e)
		{
		//	System.out.println("in DateTimeParseException ---------------------");
			return false;
		}
		
		return true;
	}

	@Override
	public boolean isValidDOB(LocalDate date)
	{
		LocalDate today=LocalDate.now();
		Period diff=date.until(today);
		//System.out.println("Age-----------------"+diff.getYears());
		if(diff.getYears()<20)
		{
			return false;
		}
		else
		{
			return true;
		}
	
	}

	@Override
	public boolean isValidDOJ(LocalDate date,LocalDate eDOJ)
	{
		Period diff=date.until(eDOJ);
		if(diff.getYears()<20)
		{
			return false;
		}
		else
		{
			return true;
		}
	}

	@Override
	public boolean isPastDateForLeave(LocalDate date)
	{
		LocalDate today=LocalDate.now();
		Period diff=date.until(today);
		// remove =0, if want to apply the leave of current date also
		if(diff.getYears()>0 || diff.getMonths()>0 || diff.getDays()>=0)
		{
			return false;
		}
		else
		{
			return true;
		}
	}

	@Override
	public boolean isValidateLeaveId(int lId, ArrayList<Integer> leaveIdList) {
		if(leaveIdList.contains(lId)) {
			return true;
		}
		else {
			return false;
		}
	}

	@Override
	public boolean isValidtoDate(LocalDate fromLocalDate, LocalDate toLocalDate) {
		Period diff=fromLocalDate.until(toLocalDate);
		//System.out.println("Age-----------------"+diff.getYears());
		//System.out.println(diff.getDays()+" "+diff.getMonths()+" "+diff.getYears());
		if(diff.getDays()<0 || diff.getMonths()<0 || diff.getYears()<0)
		{
			return false;
		}
		else
		{
			return true;
		}
	}
}
