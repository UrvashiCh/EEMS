package com.cg.ems.service;

import java.io.IOException;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import com.cg.ems.dto.Department;
import com.cg.ems.dto.Employee;
import com.cg.ems.dto.GradeMaster;
import com.cg.ems.exception.EmployeeException;

public interface AdminService 
{
	public int addEmployee(Employee emp)throws EmployeeException, ClassNotFoundException, SQLException, IOException;
	public int[] salaryBracket(String id) throws EmployeeException, ClassNotFoundException, SQLException, IOException;
	public String getDepartment(int id) throws EmployeeException, ClassNotFoundException, SQLException, IOException;
	public ArrayList<Department> displayDepartment()throws EmployeeException, ClassNotFoundException, SQLException, IOException;
	public ArrayList <GradeMaster> getGradeCodes()throws EmployeeException, ClassNotFoundException, SQLException, IOException;
	public ArrayList <Employee> displayAllEmployee() throws EmployeeException, ClassNotFoundException, SQLException, IOException;
	public ArrayList<Employee> getManagers() throws ClassNotFoundException, SQLException, IOException;
	public int addLogin(Employee emp) throws ClassNotFoundException, SQLException, IOException;
	public String fetchEmpName(String empId) throws ClassNotFoundException, SQLException, IOException;
	public int updateEmployee(Employee emp) throws EmployeeException;
	public Employee getEmployeeById(String id)throws EmployeeException;
	
	public boolean isValidateEmpId(String empId);
	public boolean isValidateName(String empName,int flag) ;
	public boolean isValidateDeptID(ArrayList <Integer>validateDepId,int depId);
	public boolean isValidGradeCode(ArrayList <String>validateGradeCode,String gradeCode);
	public boolean isValidSalary(int[] salBracket,int eSal);
	public boolean isValidGender(int gen);
	public boolean isValidMaritialStatus(int status);
	public boolean isValidContact(long contact);
	public boolean isValidDesignation(String desig);
	public boolean isValidDateFormat(String input);
	public boolean isValidDOB(LocalDate date);
	public boolean isValidDOJ(LocalDate date,LocalDate eDOJ); 
	public boolean isPastDateForLeave(LocalDate date);
	public boolean isValidateMngrId(ArrayList<String> validateDepId, String eMngID);
	public boolean isValidateLeaveId(int lId, ArrayList<Integer> leaveIdList);
	public boolean isValidtoDate(LocalDate fromLocalDate, LocalDate toLocalDate);
	
}
