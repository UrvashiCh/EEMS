//This is the main class where the application interacts with the user via a console.

package com.cg.ems.ui;

import java.io.IOException;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.Scanner;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.cg.ems.dto.Department;
import com.cg.ems.dto.Employee;
import com.cg.ems.dto.GradeMaster;
import com.cg.ems.dto.LeaveRecords;
import com.cg.ems.dto.UserMaster;
import com.cg.ems.exception.EmployeeException;
import com.cg.ems.service.AdminService;
import com.cg.ems.service.AdminServiceImpl;
import com.cg.ems.service.EmployeeService;
import com.cg.ems.service.EmployeeServiceImpl;
import com.cg.ems.service.LoginService;
import com.cg.ems.service.LoginServiceImpl;
/*
 * In the EmsMain class the Scanner Object is defined to read the user Input
 * The LoginService, AdminService, EmployeeService Objects are defined to interact with the service class
 * The Logger Object is also defined to log all the error/success messages
 */

/*
 * From EMSMain class we get 2 option for login one as Employee and other as ADMIN
 * On selecting option of ADMIN Login AdminLogin method is called
 * on selecting option of Employee login EmployeeLogin method is called
 */
public class EmsMain {
	static Scanner sc = new Scanner(System.in);
	static LoginService loginService = null;
	static AdminService adminService = null;
	static EmployeeService empService = null;
	static Logger emsLogger = null;
	static boolean login = false;
	public static void main(String[] args) throws ClassNotFoundException, SQLException, IOException {
		loginService = new LoginServiceImpl();
		adminService = new AdminServiceImpl();
		empService = new EmployeeServiceImpl();
		emsLogger = Logger.getLogger(EmsMain.class);
		PropertyConfigurator.configure("log4j.properties");
		while (!login) {
			System.out.println(
					"******************************Welcome to Employee Management System*******************************");
			System.out.println(" 1. Login As Admin.");
			System.out.println(" 2. Login as Employee.");
			System.out.println("You Want To Login As...........");
			int choice = sc.nextInt();
			String id;
			String pass;
			UserMaster um;
			switch(choice) {
			case 1:
				System.out.println("Enter AdminID....");
				id = sc.next();
				System.out.println("Please Enter your Password....");
				pass = sc.next();
				um = new UserMaster(id, pass);
				try {
					login=true;
					AdminLogin(um);
				}catch (Exception e) {
					emsLogger.fatal("Invalid Credentials");
					System.out.println(e.getMessage());
					login=false;
				}
				break;

			case 2:
				System.out.println("Enter EmployeeID....");
				id = sc.next();
				System.out.println("Please Enter your Password....");
				pass = sc.next();
				um = new UserMaster(id, pass);
				try {
					login=true;
					EmployeeLogin(um);
				} catch (Exception e) {
					emsLogger.fatal("Invalid Credentials");
					System.out.println(e.getMessage());
					login=false;
				}
				break;

			default:
				emsLogger.warn("Invalid Option Selected");
				System.out.println("Invalid Option");
				break;
			}

		}
	}
	/*	
	 * This method is used to validate ADMIN Login and perform ADMIN functionalities
	 *  like Add Employee,Modify Employee,Search Employee,Display All Employee
	 */
	public static void AdminLogin(UserMaster um) throws SQLException, EmployeeException, ClassNotFoundException, IOException {
		String admin = loginService.EmployeeType(um);
		if(admin.equalsIgnoreCase("admin")) {
			emsLogger.info("Admin Logged in");
			while (login) {
				System.out.println(
						"*********************WELCOME TO " + admin.toUpperCase() + " LOGIN****************************");
				System.out.println("Enter Your Choice...");
				System.out.println("1. Add Employee");
				System.out.println("2. Modify Employee");
				System.out.println("3. Search Employee");
				System.out.println("4. Display All Employees");
				System.out.println("5. Sign Out");
				int choice = sc.nextInt();
				switch (choice) {
				case 1:
					addEmployee();
					break;
				case 2:
					modifyEmployee();
					break;
				case 3:
					searchEmployee();
					break;
				case 4:
					displayAllEmployees();
					break;
				case 5:
					login = false;
					emsLogger.debug("Sign Out");
					break;
				default:
					emsLogger.warn("Invalid Option Selected");
					break;
				}
			}
		}
		else {
			throw new EmployeeException("Invalid Credentials");
		}
	}
	/*
	 * This method is used to validate EmployeeLogin we can LoginIn as Employee or Manager
	 * On Employee Login we can perform employee Functionalities like Search Employee,Apply for Leave and Previous Leave Request
	 * On Manager Login we can perform Manager Functionalities like Search Employee and Leave Request
	*/
	private static void EmployeeLogin(UserMaster um) throws ClassNotFoundException, SQLException, IOException, EmployeeException {
		String user = loginService.EmployeeType(um);
		String type[] = user.split(" ", 2);
		if (type[0].equalsIgnoreCase("employee")) {
			emsLogger.info("Employee Logged in");
			while (login) {
				System.out.println(
						"**********************WELCOME " + type[1].toUpperCase() + " TO EMPLOYEE LOGIN***************** ");

				System.out.println("Enter Your Choice...");
				System.out.println("1. Search Employee");
				System.out.println("2. Apply for Leave");
				System.out.println("3. Previous Leave Requests");
				System.out.println("4. Sign Out");
				int choice = sc.nextInt();
				switch (choice) {
				case 1:
					searchEmployee();
					break;
				case 2:
					applyLeave(um.getUserId());
					break;
				case 3:
					previousLeave(um.getUserId());
					break;
				case 4:
					emsLogger.debug("Sign Out");
					login = false;
					break;
				default:
					emsLogger.warn("Invalid Option Selected");
					break;
				}
			}

		} else if (type[0].equalsIgnoreCase("manager")) {
			while (login) {
				emsLogger.info("Manager Logged in");
				System.out.println(
						"***********************WELCOME " + type[1].toUpperCase() + " TO MANAGER LOGIN****************** ");
				System.out.println("Enter Your Choice...");
				System.out.println("1. Search Employee");
				System.out.println("2. Leave Requests");
				System.out.println("3. Sign Out");
				int choice = sc.nextInt();
				switch (choice) {
				case 1:
					searchEmployee();
					break;
				case 2:
					leaveRequests(um.getUserId());
					break;
				case 3:
					emsLogger.debug("Sign Out");
					login = false;
					break;
				default:
					emsLogger.warn("Invalid Option Selected");
					break;
				}
			}
		}
		else {
			throw new EmployeeException("Invalid Credentials");
		}
	}
	
	/*
	 * Gets the Employee details from the user, validates all the details. If all the details are valid then
	 * adds all the data to the database and prints a success message.
	 */
	private static void addEmployee() throws EmployeeException, ClassNotFoundException, SQLException, IOException {
			emsLogger.debug("In addEmployee Function");
			String eId;
			boolean idFlag=false;
			do
			{
				System.out.println("Enter Employee ID:");
				eId=sc.next();	
				if(!adminService.isValidateEmpId(eId))
				{
					emsLogger.warn("In addEmployee Function: Employee ID Should be 6 digits");
					System.out.println("Employee ID Should be 6 digits:");
					idFlag=false;
				}
				else if(adminService.isValidateEmpId(eId))
				{
					Employee empAlreadyExist=empService.searchEmployeeById(eId);
					if(empAlreadyExist!=null)
					{
						emsLogger.warn("In addEmployee Function: Employee with entered ID already exists");
						System.out.println("Employee with entered ID already exists");
						idFlag=false;
					}
					else
					{
						idFlag=true;
					}
				}
				
			}while(!idFlag);
		
			String eFName;
			do
			{
				System.out.println("Enter Employee First Name:");
				eFName=sc.next();
				if(!adminService.isValidateName(eFName))
				{
					emsLogger.warn("In addEmployee Function: Invalid First Name");
					System.out.println("Invalid First Name, Should start with Capital:\n \n");
				}
			}while(!adminService.isValidateName(eFName));
			
			String eLName;
			do
			{
				System.out.println("Enter Employee Last Name:");
				eLName=sc.next();
				if(!adminService.isValidateName(eLName))
				{
					emsLogger.warn("In addEmployee Function: Invalid Last Name");
					System.out.println("Invalid Last Name, Should start with Capital:\n \n");
				}
			}while(!adminService.isValidateName(eLName));
			
			String eDob=null;
			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
			boolean DOBflag=false;
			LocalDate eDOB=null;
			do
			{
			System.out.println("Enter Employee Date of Birth:(dd/MM/yyyy)");
			eDob=sc.next(); 
			//boolean choice=adminService.isValidDateFormat(eDob);
			if(!adminService.isValidDateFormat(eDob))
			{
				emsLogger.warn("In addEmployee Function: Date should be valid and should be in dd/MM/yyyy format");
				System.out.println("Date should be valid and should be in dd/MM/yyyy format");
				DOBflag=false;
			}
			else if(adminService.isValidDateFormat(eDob))
			{
				eDOB = LocalDate.parse(eDob, formatter);
				if(!adminService.isValidDOB(eDOB))
				{
					emsLogger.warn("In addEmployee Function: Employee should be atleast 20 years old");
					System.out.println("Employee should be atleast 20 years old");
					DOBflag=false;
				}
				else if(adminService.isValidDOB(eDOB))
				{
					DOBflag=true;
				}
			}
			}while(!DOBflag);
			
			String eDoj=null;
			boolean DOJflag=false;
			LocalDate eDOJ = null;
			do
			{
				System.out.println("Enter Employee Date of Joining:(dd/MM/yyyy)");
				eDoj=sc.next();
				if(!adminService.isValidDateFormat(eDoj))
				{
					emsLogger.warn("In addEmployee Function: Date should be valid and should be in dd/MM/yyyy format");
					System.out.println("Date should be valid and should be in dd/MM/yyyy format");
					DOJflag=false;
				}
				else if(adminService.isValidDateFormat(eDoj))
				{
					eDOJ = LocalDate.parse(eDoj, formatter);
					if(!adminService.isValidDOJ(eDOB,eDOJ))
					{
						emsLogger.warn("In addEmployee Function: Employee Date Of Joining is not valid");
						System.out.println("Employee Date Of Joining is not valid");
						DOJflag=false;
					}
					else if(adminService.isValidDOJ(eDOB,eDOJ))
					{
						DOJflag=true;
					}
				}
			}while(!DOJflag);
						
			ArrayList<Department> depList = null;
			try {
				depList = adminService.displayDepartment();
			} catch (ClassNotFoundException | SQLException | IOException e) {
				e.printStackTrace();
			}
			ArrayList <Integer> validateDepId=new ArrayList<Integer>();
			System.out.println("\n-----------------------------------------------");
			System.out.println("Department ID\t\t Department Name");
			System.out.println("\n-----------------------------------------------");
			for(Department dep:depList)
			{
				System.out.println(dep.getDeptID()+"\t\t\t"+dep.getDeptName());
				validateDepId.add(dep.getDeptID());
			}
			System.out.println("-------------------------------------------------");
			
			int eDepId;
			do
			{
				System.out.println("Select Department ID:");
				eDepId=sc.nextInt();
				if(!adminService.isValidateDeptID(validateDepId,eDepId))
				{
					System.out.println("Selected Department ID: "+eDepId+" is Invalid:\n \n");
					System.out.println("-----------------------------------------------");
					System.out.println("Department ID\t\t Department Name");
					System.out.println("\n-----------------------------------------------");
					for(Department dep:depList)
					{
						System.out.println(dep.getDeptID()+"\t\t\t"+dep.getDeptName());
						validateDepId.add(dep.getDeptID());
					}
					System.out.println("-------------------------------------------------");
				}
			}while(!adminService.isValidateDeptID(validateDepId,eDepId));
			
			ArrayList<GradeMaster> Code = null;
			try {
				Code = adminService.getGradeCodes();
			} catch (ClassNotFoundException | SQLException | IOException e) {
				e.printStackTrace();
			}
			ArrayList <String> validateGradeCode=new ArrayList<String>();
			System.out.println("\n------------------");
			System.out.println("Grade Code");
			System.out.println("------------------");
			for(GradeMaster code:Code)
			{
				System.out.println(code.getGradeCode());
				validateGradeCode.add(code.getGradeCode());
			}
			System.out.println("------------------");
			System.out.println("Select Grade Code:");
			String eGradeCode;
			int eSal=0;
			do
			{
				eGradeCode=sc.next();
				eGradeCode=eGradeCode.toUpperCase();
				if(!adminService.isValidGradeCode(validateGradeCode,eGradeCode))
				{
					emsLogger.warn("In addEmployee Function: GradeCode Invalid");
					System.out.println("Selected GradeCode: "+eGradeCode+" is Invalid:\n \n");
					System.out.println("------------------");
					System.out.println("Grade Code");
					System.out.println("------------------");
					for(GradeMaster code:Code)
					{
						System.out.println(code.getGradeCode());
						validateGradeCode.add(code.getGradeCode());
					}
					System.out.println("------------------");
					System.out.println("Select Grade Code:");
				}
				else if(adminService.isValidGradeCode(validateGradeCode,eGradeCode))
				{
					int[] salBracket=new int[2];
					try {
						salBracket=adminService.salaryBracket(eGradeCode);
					} catch (ClassNotFoundException | SQLException | IOException e) {
						e.printStackTrace();
					}
					
					do
					{
						System.out.println("Enter Employee basic Salary in range:"+salBracket[0]+"-"+salBracket[1]);
						eSal=sc.nextInt();
						if(!adminService.isValidSalary(salBracket,eSal))
						{
							emsLogger.warn("In addEmployee Function: Entered Salary is not in Salary Range");
							System.out.println("Entered Salary is not in Salary Brackets: ["+salBracket[0]+"-"+salBracket[1]+"]:\n \n ");
						}
					}while(!adminService.isValidSalary(salBracket,eSal));
				}
			}while(!adminService.isValidGradeCode(validateGradeCode,eGradeCode));
			
			
			String eDesig;
			do
			{
				System.out.println("Enter Employee Designation:");
				eDesig=sc.next();	
				if(!adminService.isValidDesignation(eDesig))
				{
					emsLogger.warn("In addEmployee Function: Designation Length cannot be greater than 15");
					System.out.println("Designation Length cannot be greater than 15.");
				}
			}while(!adminService.isValidDesignation(eDesig));			
			
			int gen;
			String eGender=null;
			do
			{
				System.out.println("Select Gender:\n 1. Male \n 2. Female  \n 3. Other");
				gen=sc.nextInt();
				if(!adminService.isValidGender(gen))
				{
					emsLogger.warn("In addEmployee Function: Entered Gender in not valid");
					System.out.println("Entered Gender in not valid:\n \n");
				}
				else if(adminService.isValidGender(gen))
				{
				
					switch(gen)
					{
					case 1: eGender="M";
					break;
					case 2: eGender="F";
					break;
					case 3: eGender="O";
					break;
					}
				}				
			}while(!adminService.isValidGender(gen));
			
			int status;
			String eMarStatus=null;
			do
			{
				System.out.println("Select Maritial Status:\n 1. Single\n 2. Married\n 3. Divorced\n 4. Seperated\n 5. Widowed");
				status=sc.nextInt();
				if(!adminService.isValidMaritialStatus(status))
				{
					emsLogger.warn("In addEmployee Function: Entered Maritial Status in not valid");
					System.out.println("Entered Maritial Status in not valid:\n \n");
				}
				else if(adminService.isValidMaritialStatus(status))
				{
					switch(status)
					{
					case 1: eMarStatus="S";
					break;
					case 2: eMarStatus="M";
					break;
					case 3: eMarStatus="D";
					break;
					case 4: eMarStatus="S";
					break;
					case 5: eMarStatus="W";
					break;
					}
				}
			}while(!adminService.isValidMaritialStatus(status));
			
			System.out.println("Enter Employee Address:");
			String eAddr=sc.next();
			
			long eContact;
			do
			{
				System.out.println("Enter Employee Contact Number:");
				eContact=sc.nextLong();
				if(!adminService.isValidContact(eContact))
				{
					emsLogger.warn("In addEmployee Function: Invalid contact number");
					System.out.println("Invalid contact number, should be 10 digits:\n \n");
				}
			}while(!adminService.isValidContact(eContact));
			
			String eMngID;
			ArrayList <String> validMngrId;
			do
			{
				System.out.println("Enter Employee Manager ID:");
				ArrayList<Employee> mngrList = adminService.getManagers(eDepId);
				validMngrId = new ArrayList<String>();
				System.out.println("\n------------------");
				System.out.println("Managers Available");
				System.out.println("------------------");
				for(Employee emp : mngrList)
				{
					System.out.println(emp.getEmpID()+"\t"+emp.getEmpFirstName());
					validMngrId.add(emp.getEmpID());
				}
				System.out.println("------------------");
				System.out.println("Insert Manager Id:");
				eMngID=sc.next();

				if(!adminService.isValidateEmpId(eMngID))
				{
					emsLogger.warn("In addEmployee Function: Manager ID should be 6 digits");
					System.out.println("Manager ID should be 6 digits");	
				}
			}while(!adminService.isValidateMngrId(validMngrId,eMngID));			
			Employee emp=new Employee(eId,eFName,eLName,eDOB,eDOJ,eDepId,eGradeCode,eDesig,eSal,eGender,eMarStatus,eAddr,eContact,eMngID);
			int iChoice1 = adminService.addEmployee(emp);
			int iChoice2 = adminService.addLogin(emp);
			if(iChoice1==1) {
				if(iChoice2==1) {
					emsLogger.info("In addEmployee Function: Employee added Successfully");
					System.out.println("Employee added Successfully");
					System.out.println("For Employee Login :");
					System.out.println("UserId will be the Employee Id and Password will be the First Name of the Employee in lowercase");
				}
			}
			else
			{
				emsLogger.warn("In addEmployee Function: Insert Operation failed");
				System.out.println("Insert Operation failed");
			}
				
	}
	
	/*
	 * This function updates the various employee details based on its employee id
	 */
	private static void modifyEmployee() throws EmployeeException, ClassNotFoundException, SQLException, IOException {
		emsLogger.debug("In modifyEmployee Function");
		boolean flag=true;
		String id;
		do
		{
			System.out.println("Enter Employee ID:");
			id=sc.next();	
			if(!adminService.isValidateEmpId(id))
			{
				emsLogger.warn("In modifyEmployee Function: Employee ID Should be 6 digits");
				System.out.println("Employee ID Should be 6 digits:");
				flag=false;
			}
			else if(adminService.isValidateEmpId(id))
			{
				Employee empAlreadyExist=empService.searchEmployeeById(id);
				if(empAlreadyExist==null)
				{
					emsLogger.warn("In modifyEmployee Function: Employee with entered ID doesn't exists");
					System.out.println("Employee with entered ID doesn't exists");
					flag=false;
				}
				else
				{
					flag=true;
				}
			}
			
		}while(!flag);
			
		try {
			Employee emp = adminService.getEmployeeById(id);
			while(flag) {
				System.out.println("1.Update First Name\n"
					+ "2.Update Last Name\n"
					+ "3.Update Department\n"
					+ "4.Update GradeCode\n"
					+ "5.Update Designation\n"
					+ "6.Update Gender\n"
					+ "7.Update Maritial Status\n"
					+ "8.Update Address\n"
					+ "9.Update contact\n"
					+ "10.Update DOB\n"
					+ "11.Update DOJ\n"
					+ "12.Exit");
		
		int choice = 0;
		System.out.println("Select an Option:");
		choice = sc.nextInt();
		int status = 0;
		switch (choice) {
		case 1:
			emsLogger.info("In modifyEmployee Function: Updating First Name");
			String eFName;
			do {

				System.out.println("Enter Employee First Name:");
				eFName = sc.next();
				if (!adminService.isValidateName(eFName)) {
					emsLogger.warn("In modifyEmployee Function: Invalid First Name");
					System.out.println("Invalid First Name, Should start with Capital:\n \n");
				}
			} while (!adminService.isValidateName(eFName));
			emp.setEmpFirstName(eFName);
			status = adminService.updateEmployee(emp);
			if (status==1) {
				emsLogger.info("In modifyEmployee Function: Update Successfull");
				System.out.println("Update Successfull");
			}
			else {
				emsLogger.warn("In modifyEmployee Function: Update Failed");
				System.out.println("Update Failed");
			}
			break;

		case 2:
			emsLogger.info("In modifyEmployee Function: Updating Last Name");
			String eLName;
			do {
				System.out.println("Enter Employee Last Name:");
				eLName = sc.next();
				if (!adminService.isValidateName(eLName)) {
					emsLogger.warn("In modifyEmployee Function: Invalid Last Name");
					System.out.println("Invalid Last Name, Should start with Capital:\n \n");
				}
			} while (!adminService.isValidateName(eLName));
			emp.setEmpLastName(eLName);
			status = adminService.updateEmployee(emp);
			if (status==1) {
				emsLogger.info("In modifyEmployee Function: Update Successfull");
				System.out.println("Update Successfull");
			}
			else {
				emsLogger.warn("In modifyEmployee Function: Update Failed");
				System.out.println("Update Failed");
			}
			break;
			
		case 3:
			emsLogger.info("In modifyEmployee Function: Updating Department");
			ArrayList<Department> depList = adminService.displayDepartment();
			ArrayList<Integer> validateDepId = new ArrayList<Integer>();
			System.out.println("\n-----------------------------------------------");
			System.out.println("Department ID\t\t Department Name");
			System.out.println("\n-----------------------------------------------");
			for (Department dep : depList) {
				System.out.println(dep.getDeptID() + "\t\t\t" + dep.getDeptName());
				validateDepId.add(dep.getDeptID());
			}
			System.out.println("-------------------------------------------------");

			int eDepId;
			do {
				System.out.println("Select Department ID:");
				eDepId = sc.nextInt();
				if (!adminService.isValidateDeptID(validateDepId, eDepId)) {
					System.out.println("Selected Department ID: " + eDepId + " is Invalid:\n \n");

					System.out.println("-----------------------------------------------");
					System.out.println("Department ID\t\t Department Name");
					System.out.println("\n-----------------------------------------------");
					for (Department dep : depList) {
						System.out.println(dep.getDeptID() + "\t\t\t" + dep.getDeptName());
						validateDepId.add(dep.getDeptID());
					}
					System.out.println("-------------------------------------------------");
				}
			} while (!adminService.isValidateDeptID(validateDepId, eDepId));
			emp.setEmpDeptID(eDepId);
			status = adminService.updateEmployee(emp);
			if (status==1) {
				emsLogger.info("In modifyEmployee Function: Update Successfull");
				System.out.println("Update Successfull");
			}
			else {
				emsLogger.warn("In modifyEmployee Function: Update Failed");
				System.out.println("Update Failed");
			}
			break;
			
		case 4:
			emsLogger.info("In modifyEmployee Function: Updating Grade Code");
			ArrayList<GradeMaster> Code = adminService.getGradeCodes();
			ArrayList<String> validateGradeCode = new ArrayList<String>();
			System.out.println("\n------------------");
			System.out.println("Grade Code");
			System.out.println("------------------");
			for (GradeMaster code : Code) {
				System.out.println(code.getGradeCode());
				validateGradeCode.add(code.getGradeCode());
			}
			System.out.println("------------------");
			System.out.println("Select Grade Code:");
			String eGradeCode;
			int eSal = 0;
			do {
				eGradeCode = sc.next();
				eGradeCode = eGradeCode.toUpperCase();
				if (!adminService.isValidGradeCode(validateGradeCode, eGradeCode)) {
					emsLogger.warn("In modifyEmployee Function: Entered GradeCode is Invalid");
					System.out.println("Selected GradeCode: " + eGradeCode + " is Invalid:\n \n");
					System.out.println("------------------");
					System.out.println("Grade Code");
					System.out.println("------------------");
					for (GradeMaster code : Code) {
						System.out.println(code.getGradeCode());
						validateGradeCode.add(code.getGradeCode());
					}
					System.out.println("------------------");
					System.out.println("Select Grade Code:");
				} else if (adminService.isValidGradeCode(validateGradeCode, eGradeCode)) {
					int[] salBracket = new int[2];
					salBracket = adminService.salaryBracket(eGradeCode);

					do {
						System.out.println("Enter Employee basic Salary in range :"+salBracket[0]+"-"+salBracket[1]);
						eSal = sc.nextInt();
						if (!adminService.isValidSalary(salBracket, eSal)) {
							emsLogger.warn("In modifyEmployee Function: Entered Salary is not in Salary Range");
							System.out.println("Entered Salary is not in Salary Brackets: [" + salBracket[0] + "-"
									+ salBracket[1] + "]:\n \n ");
						}
					} while (!adminService.isValidSalary(salBracket, eSal));
				}
			} while (!adminService.isValidGradeCode(validateGradeCode, eGradeCode));
			emp.setEmpGrade(eGradeCode);
			emp.setEmpBasicSal(eSal);
			status = adminService.updateEmployee(emp);
			if (status==1) {
				emsLogger.info("In modifyEmployee Function: Update Successfull");
				System.out.println("Update Successfull");
			}
			else {
				emsLogger.warn("In modifyEmployee Function: Update Failed");
				System.out.println("Update Failed");
			}
			break;
			
		case 5:
			emsLogger.info("In modifyEmployee Function: Updating Designation");
			System.out.println("Enter Employee Designation:");
			String eDesig = sc.next();
			emp.setEmpDesignation(eDesig);
			status = adminService.updateEmployee(emp);
			if (status==1) {
				emsLogger.info("In modifyEmployee Function: Update Successfull");
				System.out.println("Update Successfull");
			}
			else {
				emsLogger.warn("In modifyEmployee Function: Update Failed");
				System.out.println("Update Failed");
			}
			break;
		case 6:
			emsLogger.info("In modifyEmployee Function: Updating Gender");
			int gen;
			String eGender = null;
			do {
				System.out.println("Select Gender:\n 1. Male \n 2. Female  \n 3. Other");
				gen = sc.nextInt();
				if (!adminService.isValidGender(gen)) {
					emsLogger.warn("In modifyEmployee Function: Entered Gender in not valid");
					System.out.println("Entered Gender in not valid:\n \n");
				} else if (adminService.isValidGender(gen)) {

					switch (gen) {
					case 1:
						eGender = "M";
						break;
					case 2:
						eGender = "F";
						break;
					case 3:
						eGender = "O";
						break;
					}
				}
			} while (!adminService.isValidGender(gen));
			emp.setEmpGender(eGender);
			status = adminService.updateEmployee(emp);
			if (status==1) {
				emsLogger.info("In modifyEmployee Function: Update Successfull");
				System.out.println("Update Successfull");
			}
			else {
				emsLogger.warn("In modifyEmployee Function: Update Failed");
				System.out.println("Update Failed");
			}
			break;
		
		case 7:
			emsLogger.info("In modifyEmployee Function: Updating Marital Status");
			int mstatus = 0;
			String eMarStatus = null;
			do {
				System.out.println("Select Maritial Status:\n 1. Single\n 2. Married\n 3. Divorced\n 4. Seperated\n 5. Widowed");
				mstatus = sc.nextInt();
				if (!adminService.isValidMaritialStatus(mstatus)) {
					emsLogger.warn("In modifyEmployee Function: Entered Maritial Status in not valid");
					System.out.println("Entered Maritial Status in not valid:\n \n");
				} else if (adminService.isValidMaritialStatus(mstatus)) {

					switch (mstatus) {
					case 1:
						eMarStatus = "S";
						break;
					case 2:
						eMarStatus = "M";
						break;
					case 3:
						eMarStatus = "D";
						break;
					case 4:
						eMarStatus = "S";
						break;
					case 5:
						eMarStatus = "W";
						break;
					}
				}
			} while (!adminService.isValidMaritialStatus(mstatus));
			emp.setEmpMaritalStatus(eMarStatus);
			status = adminService.updateEmployee(emp);
			if (status==1) {
				emsLogger.info("In modifyEmployee Function: Update Successfull");
				System.out.println("Update Successfull");
			}
			else {
				emsLogger.warn("In modifyEmployee Function: Update Failed");
				System.out.println("Update Failed");
			}
			break;
			
		case 8:
			emsLogger.info("In modifyEmployee Function: Updating Address");
			System.out.println("Enter Employee Address:");
			String eAddr = sc.next();
			emp.setEmpHomeAddress(eAddr);
			status = adminService.updateEmployee(emp);
			if (status==1) {
				emsLogger.info("In modifyEmployee Function: Update Successfull");
				System.out.println("Update Successfull");
			}
			else {
				emsLogger.warn("In modifyEmployee Function: Update Failed");
				System.out.println("Update Failed");
			}
			break;
			
			
		case 9:
			emsLogger.info("In modifyEmployee Function: Updating Contact");
			long eContact;
			do {
				System.out.println("Enter Employee Contact Number:");
				eContact = sc.nextLong();
				if (!adminService.isValidContact(eContact)) {
					emsLogger.warn("In modifyEmployee Function: Invalid contact number");
					System.out.println("Invalid contact number, should be 10 digits:\n \n");
				}
			} while (!adminService.isValidContact(eContact));
			emp.setEmpContactNum(eContact);
			status = adminService.updateEmployee(emp);
			if (status==1) {
				emsLogger.info("In modifyEmployee Function: Update Successfull");
				System.out.println("Update Successfull");
			}
			else {
				emsLogger.warn("In modifyEmployee Function: Update Failed");
				System.out.println("Update Failed");
			}
			break;
		case 10:
			emsLogger.info("In modifyEmployee Function: Updating DOB");
			String eDob=null;
			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
			boolean DOBflag=false;
			LocalDate eDOB=null;
			do
			{
			System.out.println("Enter Employee Date of Birth:(dd/MM/yyyy)");
			eDob=sc.next(); 
			//boolean choice=adminService.isValidDateFormat(eDob);
			if(!adminService.isValidDateFormat(eDob))
			{
				emsLogger.warn("In addEmployee Function: Date should be valid and should be in dd/MM/yyyy format");
				System.out.println("Date should be valid and should be in dd/MM/yyyy format");
				DOBflag=false;
			}
			else if(adminService.isValidDateFormat(eDob))
			{
				eDOB = LocalDate.parse(eDob, formatter);
				if(!adminService.isValidDOB(eDOB))
				{
					emsLogger.warn("In addEmployee Function: Employee should be atleast 20 years old");
					System.out.println("Employee should be atleast 20 years old");
					DOBflag=false;
				}
				else if(adminService.isValidDOB(eDOB))
				{
					DOBflag=true;
					emp.setEmpDateofBirth(eDOB);
				}
			}
			}while(!DOBflag);
			status = adminService.updateEmployee(emp);
			if (status==1) {
				emsLogger.info("In modifyEmployee Function: Update Successfull");
				System.out.println("Update Successfull");
			}
			else {
				emsLogger.warn("In modifyEmployee Function: Update Failed");
				System.out.println("Update Failed");
			}
			break;
			
		case 11:
			emsLogger.info("In modifyEmployee Function: Updating DOJ");
			String eDoj=null;
			eDOB = emp.getEmpDateofBirth();
			boolean DOJflag=false;
			LocalDate eDOJ = null;
			formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
			do
			{
				System.out.println("Enter Employee Date of Joining:(dd/MM/yyyy)");
				eDoj=sc.next();
				if(!adminService.isValidDateFormat(eDoj))
				{
					emsLogger.warn("In addEmployee Function: Date should be valid and should be in dd/MM/yyyy format");
					System.out.println("Date should be valid and should be in dd/MM/yyyy format");
					DOJflag=false;
				}
				else if(adminService.isValidDateFormat(eDoj))
				{
					eDOJ = LocalDate.parse(eDoj, formatter);
					if(!adminService.isValidDOJ(eDOB,eDOJ))
					{
						emsLogger.warn("In addEmployee Function: Employee Date Of Joining is not valid");
						System.out.println("Employee Date Of Joining is not valid");
						DOJflag=false;
					}
					else if(adminService.isValidDOJ(eDOB,eDOJ))
					{
						DOJflag=true;
						emp.setEmpDateofJoining(eDOJ);
					}
				}
			}while(!DOJflag);
			status = adminService.updateEmployee(emp);
			if (status==1) {
				emsLogger.info("In modifyEmployee Function: Update Successfull");
				System.out.println("Update Successfull");
			}
			else {
				emsLogger.warn("In modifyEmployee Function: Update Failed");
				System.out.println("Update Failed");
			}
			break;
		case 12:
			emsLogger.info("In modifyEmployee Function: Sign Out");
			flag=false;
			break;
			
		default:
			emsLogger.warn("In modifyEmployee Function: Invalid Option");
			System.out.println("Invalid Option");
			break;
		}
		}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
	/*
	 * Searches for the employee according to various given fields and returns the result.
	 */
	private static void searchEmployee() {
		emsLogger.debug("In searchEmployee Function");
		boolean searched = false;
		while(!searched)
		{
			System.out.println("\nWhat do you want to do \n");
			System.out.println("1.Search employee by id \n2.Search employee by first name \n3.Search Employee by last name \n4.Search Employee by Department Id \n5.Search Employee by grade \n6.Search employee by Marital Status \n7.Go Back \n");
			int choice = sc.nextInt();
			try {
				switch(choice)
				{
					case 1:
						searchById();
						break;
					case 2:
						searchByFirstName();
						break;
					case 3:
						searchByLastName();
						break;
					case 4:
						searchByDepartmentId();
						break;
					case 5:
						searchByGrade();
						break;
					case 6:
						searchByMaritalStatus();
						break;
					case 7:
						emsLogger.info("In searchEmployee Function: Go Back");
						searched = true;
						break;
					default:
						emsLogger.warn("In searchEmployee Function: Invalid Option");
						System.out.println("Invalid Option");
						break;							
				}
			}catch (Exception e) {
				e.printStackTrace();
			}
		}		
	}
	//Search using employee id
	private static void searchById() throws ClassNotFoundException, EmployeeException, SQLException, IOException {
		emsLogger.debug("In searchById Function");
		String id;
		do {
			System.out.println("Enter the id of employee to be searched");
			id=sc.next();
			if(!adminService.isValidateEmpId(id))
			{
				emsLogger.warn("In searchById Function: Employee ID Should be 6 digits");
				System.out.println("Employee ID Should be 6 digits:");
			}
		}while(!adminService.isValidateEmpId(id));
		Employee emp = empService.searchEmployeeById(id);
		if(emp==null) {
			emsLogger.info("In searchById Function: No Employee with such id exists");
			System.out.println("No Employee with such id exists");
		}
		else {
			System.out.println(emp);
		}
	}
	//Search using employee First Name
	private static void searchByFirstName() throws ClassNotFoundException, EmployeeException, SQLException, IOException {
		emsLogger.debug("In searchByFirstName Function");
		String firstName;
		do
		{
			System.out.println("Enter the first name of the employee to be searched");
			firstName = sc.next();
			if(!adminService.isValidateName(firstName))
			{
				emsLogger.warn("In searchByFirstName Function: Invalid First Name");
				System.out.println("Invalid First Name, Should start with Capital");
			}
		}while(!adminService.isValidateName(firstName));
		ArrayList<Employee> list = empService.searchEmployeeByFirstName(firstName);
		if(list.isEmpty()) {
			emsLogger.info("In searchByFirstName Function: No Records Found");
			System.out.println("No Record found");
		}
		else
		{
			for(Employee empObj : list) {
				System.out.println(empObj);
			}
		}	
	}
	//Search using employee Last Name
	private static void searchByLastName() throws ClassNotFoundException, EmployeeException, SQLException, IOException {
		emsLogger.debug("In searchByLastName Function");
		String lastName;
		do
		{
			System.out.println("Enter the last name of the employee to be searched");
			lastName = sc.next();
			if(!adminService.isValidateName(lastName)) {
				emsLogger.warn("In searchByLastName Function: Invalid Last Name");
				System.out.println("Invalid Last Name, Should start with Capital");
			}
		}while(!adminService.isValidateName(lastName));
		ArrayList<Employee> list = empService.searchEmployeeByLastName(lastName);
		if(list.isEmpty()) {
			emsLogger.info("In searchByLastName Function: No Records Found");
			System.out.println("No Record found");
		}
		else
		{
			for(Employee empObj : list) {
				System.out.println(empObj);
			}
		}	
	}
	//Search using DepartmentId
	private static void searchByDepartmentId() throws EmployeeException, ClassNotFoundException, SQLException, IOException {
		emsLogger.debug("In searchByDepartmentId Function");
		int id;
		ArrayList <Integer> validateDepId=new ArrayList<Integer>();
		ArrayList<Department> depList = adminService.displayDepartment();
        System.out.println("Select department id:");
		for(Department dep:depList)
		{
			validateDepId.add(dep.getDeptID());
		}
		System.out.println(validateDepId);
        do
        {
			System.out.println("Enter the department id of the employee to be searched");
			id=sc.nextInt();
			if(!adminService.isValidateDeptID(validateDepId,id))
			{
				emsLogger.warn("In searchByDepartmentId Function: Enter a valid department id");
				System.out.println("Enter a valid department id");
			}
        }while(!adminService.isValidateDeptID(validateDepId,id));
		ArrayList<Employee> list = empService.searchEmployeeByDeptId(id);
		if(list.isEmpty()) {
			emsLogger.info("In searchByDepartmentId Function: No Records Found");
			System.out.println("No Record found");
		}
		else
		{
			for(Employee empObj : list) {
				System.out.println(empObj);
			}
		}
	}
	//Search using employee grade
	private static void searchByGrade() throws ClassNotFoundException, EmployeeException, SQLException, IOException {
		emsLogger.debug("In searchByGrade Function");
		String grade;
		ArrayList<GradeMaster> codeList = adminService.getGradeCodes();
	    ArrayList <String> validateGradeCode=new ArrayList<String>();
	    System.out.println("Select Grade:");
	    for(GradeMaster code:codeList)
		{
			validateGradeCode.add(code.getGradeCode());
		}
		System.out.println(validateGradeCode);
		do {	
			System.out.println("Enter the grade of the employee to be searched");
			grade=sc.next();
			if(!adminService.isValidGradeCode(validateGradeCode, grade))
			{
				emsLogger.warn("In searchByGrade Function: Invalid Grade Entered");
				System.out.println("Enter a valid grade");
			}
		}while(!adminService.isValidGradeCode(validateGradeCode, grade));
		ArrayList<Employee> list = empService.searchEmployeeByGrade(grade);
		if(list.isEmpty()) {
			emsLogger.info("In searchByGrade Function: No Records Found");
			System.out.println("No Record found");
		}
		else
		{
			for(Employee empObj : list) {
				System.out.println(empObj);
			}
		}
		
	}
	//Search using marital status
	private static void searchByMaritalStatus() throws EmployeeException, ClassNotFoundException, SQLException, IOException {
		emsLogger.debug("In searchByMaritalStatus Function");
		String eMarStatus=null;
		int status;
		do
		{
			System.out.println("Select Maritial Status:\n 1. Single\n 2. Married\n 3. Divorced\n 4. Seperated\n 5. Widowed");
			status=sc.nextInt();
			if(!adminService.isValidMaritialStatus(status))
			{
				emsLogger.warn("In searchByMaritalStatus Function: Invalid Option Selected");
				System.out.println("Entered Maritial Status is not valid:\n \n");
			}
			else if(adminService.isValidMaritialStatus(status))
			{
	           switch(status)
				{
				case 1: eMarStatus="S";
				break;
				case 2: eMarStatus="M";
				break;
				case 3: eMarStatus="D";
				break;
				case 4: eMarStatus="S";
				break;
				case 5: eMarStatus="W";
				break;
				}
			}
		}while(!adminService.isValidMaritialStatus(status));
		ArrayList<Employee> list=empService.searchEmployeeByMaritalStatus(eMarStatus);
		if(list.isEmpty()) {
			emsLogger.info("In searchByMaritalStatus Function: No Record found");
			System.out.println("No Record found");
		}
		else
		{
			for(Employee empObj : list) {
				System.out.println(empObj);
			}
		}

	}
	//display lisr of all employees
	private static void displayAllEmployees() throws ClassNotFoundException, EmployeeException, SQLException, IOException {
		emsLogger.debug("In displayAllEmployees Function");
		ArrayList<Employee> empList = null;
			empList = adminService.displayAllEmployee();
			for(Employee emp : empList)
			{
				System.out.println(emp);
			}
	}
	/*
	 * The applyLeave method is used to apply for a new leave for the employee. All the validations and all are being carried out before application of leave
	 * @param  Employee Id
	 */
	private static void applyLeave(String empId) throws ClassNotFoundException, SQLException, IOException, EmployeeException {
		emsLogger.debug("In applyLeave Function");
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
		ArrayList<LeaveRecords> list = empService.fetchPastLeaveDates(empId);			
		LocalDate fromLocalDate=null;
		LocalDate toLocalDate=null;
		boolean leaveFlag=false;
		do {
			boolean fromleaveFlag=false;
			String fromDate=null;
			String toDate = null;
			do
			{
				System.out.println("Enter 'FROM' Date in format dd/MM/yyyy :");
				fromDate = sc.next();
				if(!adminService.isValidDateFormat(fromDate))
				{
					emsLogger.warn("In applyLeave Function: Date should be valid");
					System.out.println("Date should be valid and should be in dd/MM/yyyy format");
					fromleaveFlag=false;
				}
				else if(adminService.isValidDateFormat(fromDate))
				{
					fromLocalDate = LocalDate.parse(fromDate, formatter);
					if(!adminService.isPastDateForLeave(fromLocalDate))
					{
						emsLogger.warn("In applyLeave Function: Leave for Current/Past Date cannot be applied");
						System.out.println("Leave for Current/Past Date cannot be applied");
						fromleaveFlag=false;
					}
					else if(adminService.isPastDateForLeave(fromLocalDate))
					{
						if(!adminService.isValidLeavedate(fromLocalDate,list,1)) {
							emsLogger.warn("In applyLeave Function: Leave Request for entered Date is already applied");
							System.out.println("Leave Request for entered Date is already applied");
							fromleaveFlag=false;
						}
						else {
							fromleaveFlag=true;
						}
					}
				}
			}while(!fromleaveFlag);
			boolean toLeaveFlag=false;
			do
			{
				System.out.println("Enter 'TO' Date in format dd/MM/yyyy :");
				toDate = sc.next();
				if(!adminService.isValidDateFormat(toDate))
				{
					emsLogger.warn("In applyLeave Function: Date should be valid");
					System.out.println("Date should be valid and should be in dd/MM/yyyy format");
					toLeaveFlag=false;
				}
				else if(adminService.isValidDateFormat(toDate))
				{
					toLocalDate = LocalDate.parse(toDate, formatter);
					
					if(!adminService.isValidtoDate(fromLocalDate,toLocalDate))
					{
						emsLogger.warn("In applyLeave Function: Leave cannot be applied due to incorrect 'To' date");
						System.out.println("Leave cannot be applied due to incorrect 'To' date : Current/Past Date in comparision to 'FROM' Date");
						toLeaveFlag=false;
					}
					else if(adminService.isValidtoDate(fromLocalDate,toLocalDate))
					{
						if(!adminService.isValidLeavedate(toLocalDate,list,2)) {
							emsLogger.warn("In applyLeave Function: Leave Request for entered Date is already applied");
							System.out.println("Leave Request for entered Date is already applied");
							toLeaveFlag=false;
						}
						else {
							toLeaveFlag=true;
						}
					}				
				}
			}while(!toLeaveFlag);
			
			if(!adminService.isValidFinalLeavedate(toLocalDate,fromLocalDate,list)) {
				emsLogger.warn("In applyLeave Function: Previous Leave exists between the dates applied");
				System.out.println("Previous Leave exists between the dates applied");
				leaveFlag=false;
			}
			else if(adminService.isValidFinalLeavedate(toLocalDate,fromLocalDate,list)) {
				leaveFlag = true;
			}
			
		}while(!leaveFlag);
		empService = new EmployeeServiceImpl();		
		int leaveDuration = ((int) ChronoUnit.DAYS.between(fromLocalDate, toLocalDate))+1;
		if(empService.findEmployeePastLeaves(empId)) {
			if(leaveDuration>0) {
				int leaveBudget = empService.fetchInitialLeaveBudget(empId);
				if(leaveBudget-leaveDuration>=0) {
					LeaveRecords leaveRecord = new LeaveRecords();
					leaveRecord.setEmpId(empId);
					leaveRecord.setEmpName(adminService.fetchEmpName(empId));
					leaveRecord.setFromDate(fromLocalDate);
					leaveRecord.setToDate(toLocalDate);
					leaveRecord.setNoOfDays(leaveDuration);
					leaveRecord.setLeaveBalance(leaveBudget);
					leaveRecord.setStatus("applied");
					boolean requestStatus = empService.newLeaveRequest(leaveRecord);
					if(requestStatus) {
						emsLogger.info("In applyLeave Function: Leave Applied Successfully");
						System.out.println("Leave Applied Successfully");
					}
				}
				else {
					emsLogger.warn("In applyLeave Function: Leave Limit Exceeded");
					throw new EmployeeException("Leave Limit Exceeded");
				}
			}
			else {
				emsLogger.warn("In applyLeave Function: Dates are not in correct order");
				throw new EmployeeException("Dates are not in correct order");
			}
		}
		else {
			if(leaveDuration>0) {
				int leaveBudget = 12;
				if(leaveBudget-leaveDuration>=0) {
					LeaveRecords leaveRecord = new LeaveRecords();
					leaveRecord.setEmpId(empId);
					leaveRecord.setEmpName(adminService.fetchEmpName(empId));
					leaveRecord.setFromDate(fromLocalDate);
					leaveRecord.setToDate(toLocalDate);
					leaveRecord.setNoOfDays(leaveDuration);
					leaveRecord.setLeaveBalance(leaveBudget);
					leaveRecord.setStatus("applied");
					boolean requestStatus = empService.newLeaveRequest(leaveRecord);
					if(requestStatus) {
						emsLogger.info("In applyLeave Function: Leave Applied Successfully");
						System.out.println("Leave Applied Successfully");
					}
				}
				else {
					emsLogger.warn("In applyLeave Function: Leave Limit Exceeded");
					throw new EmployeeException("Leave Limit Exceeded");
				}
			}
			else {
				emsLogger.warn("In applyLeave Function: Dates are not in correct order");
				throw new EmployeeException("Dates are not in correct order");
			}
			
		}		
	}
	/*
	 * The previousLeave method is used to fetch all the previous leave Request of the Employee.
	 * @param  Employee Id
	 */
	private static void previousLeave(String empId) throws ClassNotFoundException, SQLException, IOException, EmployeeException {
		emsLogger.debug("In applyLeave Function");
		ArrayList<LeaveRecords> previousLeaves = empService.fetchPreviousRequests(empId);
		if(previousLeaves.isEmpty()) {
			emsLogger.info("In applyLeave Function: No Requests");
			System.out.println("No Requests");
			return;
		}
		else {
			for(LeaveRecords leaveObj : previousLeaves) {
				System.out.println(leaveObj);
			}
		}
		
	}
	/*
	 * The leaveRequests method is used to fetch the new Leave requests for the particular manager based on manager Id
	 * @param  Manager Id
	 */
	private static void leaveRequests(String mngrId) throws ClassNotFoundException, SQLException, IOException, EmployeeException {
		emsLogger.debug("In leaveRequests Function");
		ArrayList<LeaveRecords> leaveRequests = empService.fetchAllLeaveRequests(mngrId); //here this will act as the managerId of the employees
		ArrayList<Integer> leaveIdList = new ArrayList<Integer>();
		if(leaveRequests.isEmpty()) {
			emsLogger.info("In leaveRequests Function: No Pending Requests");
			System.out.println("No Pending Requests");
			return;
		}
		else {
			for(LeaveRecords leaveObj : leaveRequests) {
				leaveIdList.add(leaveObj.getLeaveId());
				System.out.println(leaveObj);
			}
			int lId;
			do {
				System.out.println("Enter the leaveId you want to modify :");
				lId = sc.nextInt();
				if(!adminService.isValidateLeaveId(lId,leaveIdList))
				{
					emsLogger.warn("In leaveRequests Function: Leave ID Invalid");
					System.out.println("Leave ID Invalid, Enter again:");
				}
			}while(!adminService.isValidateLeaveId(lId,leaveIdList));	
			int leaveBudget = empService.fetchLeaveBudget(lId);
			int leaveDuration = empService.fetchLeaveDuration(lId);
			System.out.println("Enter the Updated Status :");
			System.out.println("1-rejected");
			System.out.println("2-approved");
			int choice = sc.nextInt();
			String updatedStatus = null;
			boolean process = false; 
			if(choice == 1) {
				updatedStatus = "rejected";
				process = empService.updateLeaveRequest(lId,updatedStatus,leaveBudget);
			}
			else if(choice == 2) {
				updatedStatus = "approved";
				process = empService.updateLeaveRequest(lId,updatedStatus,leaveBudget-leaveDuration);
			}
			else {
				emsLogger.warn("In leaveRequests Function: Invalid Option Selected");
				System.out.println("Invalid Option");
				}
			
			if(process) {
				emsLogger.info("In leaveRequests Function: Leave Request Updated");
				System.out.println("Leave Request Updated");
			}
			else {
				emsLogger.warn("In leaveRequests Function: Leave Request not updated");
				throw new EmployeeException("Leave Request not updated");
			}
			return;
		}
		
	}	
}
