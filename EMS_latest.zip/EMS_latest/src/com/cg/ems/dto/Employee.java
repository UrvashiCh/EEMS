package com.cg.ems.dto;

import java.time.LocalDate;

public class Employee{
	private String empID;
	private String empFirstName;
	private String empLastName;
	private LocalDate empDateofBirth;
	private LocalDate empDateofJoining;
	private int empDeptID;
	private String empGrade;
	private String empDesignation;
	private int empBasicSal;
	private String empGender;
	private String empMaritalStatus;
	private String empHomeAddress;
	private long empContactNum;
	private String mgrId;
	public Employee() {
		super();
	}
	
	
	@Override
	public int hashCode() {
		// TODO Auto-generated method stub
		return this.empLastName.length();
	}


	@Override
	public boolean equals(Object obj) {
		
		boolean flag=false;
        Employee emp=null;
		if(obj instanceof Employee)
			emp=(Employee)obj;
		if(this.empID.equals(emp.empID) && this.empFirstName.equals(emp.empFirstName) && this.empLastName.equals(emp.empLastName) && this.empDateofBirth.equals(emp.empDateofBirth) && this.empDateofJoining.equals(emp.empDateofJoining) && this.empDeptID==emp.empDeptID && this.empGrade.equals(emp.empGrade) && this.empDesignation.equals(emp.empDesignation) && this.empBasicSal==emp.empBasicSal && this.empGender.equals(emp.empGender) && this.empMaritalStatus.equals(emp.empMaritalStatus) && this.empHomeAddress.equals(emp.empHomeAddress) && this.empContactNum==emp.empContactNum && this.mgrId.equals(emp.mgrId))
			flag=true;
		return flag;
	}

	public Employee(String empID, String empFirstName, String empLastName, LocalDate empDateofBirth,
			LocalDate empDateofJoining, int empDeptID, String empGrade, String empDesignation, int empBasicSal,
			String empGender, String empMaritalStatus, String empHomeAddress, long empContactNum, String mgrId) {
		super();
		this.empID = empID;
		this.empFirstName = empFirstName;
		this.empLastName = empLastName;
		this.empDateofBirth = empDateofBirth;
		this.empDateofJoining = empDateofJoining;
		this.empDeptID = empDeptID;
		this.empGrade = empGrade;
		this.empDesignation = empDesignation;
		this.empBasicSal = empBasicSal;
		this.empGender = empGender;
		this.empMaritalStatus = empMaritalStatus;
		this.empHomeAddress = empHomeAddress;
		this.empContactNum = empContactNum;
		this.mgrId = mgrId;
	}

	public String getEmpID() {
		return empID;
	}
	public void setEmpID(String empID) {
		this.empID = empID;
	}
	public String getEmpFirstName() {
		return empFirstName;
	}
	public void setEmpFirstName(String empFirstName) {
		this.empFirstName = empFirstName;
	}
	public String getEmpLastName() {
		return empLastName;
	}
	public void setEmpLastName(String empLastName) {
		this.empLastName = empLastName;
	}
	public LocalDate getEmpDateofBirth() {
		return empDateofBirth;
	}
	public void setEmpDateofBirth(LocalDate empDateofBirth) {
		this.empDateofBirth = empDateofBirth;
	}
	public LocalDate getEmpDateofJoining() {
		return empDateofJoining;
	}
	public void setEmpDateofJoining(LocalDate empDateofJoining) {
		this.empDateofJoining = empDateofJoining;
	}
	public String getEmpDesignation() {
		return empDesignation;
	}
	public void setEmpDesignation(String empDesignation) {
		this.empDesignation = empDesignation;
	}
	public int getEmpDeptID() {
		return empDeptID;
	}
	public void setEmpDeptID(int empDeptID) {
		this.empDeptID = empDeptID;
	}
	public String getEmpGrade() {
		return empGrade;
	}
	public void setEmpGrade(String empGrade) {
		this.empGrade = empGrade;
	}
	public int getEmpBasicSal() {
		return empBasicSal;
	}
	public void setEmpBasicSal(int empBasicSal) {
		this.empBasicSal = empBasicSal;
	}
	public String getEmpGender() {
		return empGender;
	}
	public void setEmpGender(String empGender) {
		this.empGender = empGender;
	}
	public String getEmpMaritalStatus() {
		return empMaritalStatus;
	}
	public void setEmpMaritalStatus(String empMaritalStatus) {
		this.empMaritalStatus = empMaritalStatus;
	}
	public String getEmpHomeAddress() {
		return empHomeAddress;
	}
	public void setEmpHomeAddress(String empHomeAddress) {
		this.empHomeAddress = empHomeAddress;
	}
	public long getEmpContactNum() {
		return empContactNum;
	}
	public void setEmpContactNum(long empContactNum) {
		this.empContactNum = empContactNum;
	}
	public String getMgrId() {
		return mgrId;
	}
	public void setMgrId(String mgrId) {
		this.mgrId = mgrId;
	}
	@Override
	public String toString() {
		return "Employee [empID=" + empID + ", empFirstName=" + empFirstName + ", empLastName=" + empLastName
				+ ", empDateofBirth=" + empDateofBirth + ", empDateofJoining=" + empDateofJoining + ", empDesignation="
				+ empDesignation + ", empDeptID=" + empDeptID + ", empGrade=" + empGrade + ", empBasicSal="
				+ empBasicSal + ", empGender=" + empGender + ", empMaritalStatus=" + empMaritalStatus
				+ ", empHomeAddress=" + empHomeAddress + ", empContactNum=" + empContactNum + ", mgrId=" + mgrId + "]";
	}

}
