package com.cg.ems.dto;

import java.time.LocalDate;

public class Employee {
	private String empID;
	private String empFirstName;
	private String empLastName;
	private LocalDate empDateofBirth;
	private LocalDate empDateofJoining;
	private int empDeptID;
	private String empGrade;
	private String empDesignation;
	private int empBasicSal;
	private String empGender;
	private String empMaritalStatus;
	private String empHomeAddress;
	private long empContactNum;
	private String mgrId;
	public Employee() {
		super();
	}
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + empBasicSal;
		result = prime * result + (int) (empContactNum ^ (empContactNum >>> 32));
		result = prime * result + ((empDateofBirth == null) ? 0 : empDateofBirth.hashCode());
		result = prime * result + ((empDateofJoining == null) ? 0 : empDateofJoining.hashCode());
		result = prime * result + empDeptID;
		result = prime * result + ((empDesignation == null) ? 0 : empDesignation.hashCode());
		result = prime * result + ((empFirstName == null) ? 0 : empFirstName.hashCode());
		result = prime * result + ((empGender == null) ? 0 : empGender.hashCode());
		result = prime * result + ((empGrade == null) ? 0 : empGrade.hashCode());
		result = prime * result + ((empHomeAddress == null) ? 0 : empHomeAddress.hashCode());
		result = prime * result + ((empID == null) ? 0 : empID.hashCode());
		result = prime * result + ((empLastName == null) ? 0 : empLastName.hashCode());
		result = prime * result + ((empMaritalStatus == null) ? 0 : empMaritalStatus.hashCode());
		result = prime * result + ((mgrId == null) ? 0 : mgrId.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Employee other = (Employee) obj;
		if (empBasicSal != other.empBasicSal)
			return false;
		if (empContactNum != other.empContactNum)
			return false;
		if (empDateofBirth == null) {
			if (other.empDateofBirth != null)
				return false;
		} else if (!empDateofBirth.equals(other.empDateofBirth))
			return false;
		if (empDateofJoining == null) {
			if (other.empDateofJoining != null)
				return false;
		} else if (!empDateofJoining.equals(other.empDateofJoining))
			return false;
		if (empDeptID != other.empDeptID)
			return false;
		if (empDesignation == null) {
			if (other.empDesignation != null)
				return false;
		} else if (!empDesignation.equals(other.empDesignation))
			return false;
		if (empFirstName == null) {
			if (other.empFirstName != null)
				return false;
		} else if (!empFirstName.equals(other.empFirstName))
			return false;
		if (empGender == null) {
			if (other.empGender != null)
				return false;
		} else if (!empGender.equals(other.empGender))
			return false;
		if (empGrade == null) {
			if (other.empGrade != null)
				return false;
		} else if (!empGrade.equals(other.empGrade))
			return false;
		if (empHomeAddress == null) {
			if (other.empHomeAddress != null)
				return false;
		} else if (!empHomeAddress.equals(other.empHomeAddress))
			return false;
		if (empID == null) {
			if (other.empID != null)
				return false;
		} else if (!empID.equals(other.empID))
			return false;
		if (empLastName == null) {
			if (other.empLastName != null)
				return false;
		} else if (!empLastName.equals(other.empLastName))
			return false;
		if (empMaritalStatus == null) {
			if (other.empMaritalStatus != null)
				return false;
		} else if (!empMaritalStatus.equals(other.empMaritalStatus))
			return false;
		if (mgrId == null) {
			if (other.mgrId != null)
				return false;
		} else if (!mgrId.equals(other.mgrId))
			return false;
		return true;
	}

	public Employee(String empID, String empFirstName, String empLastName, LocalDate empDateofBirth,
			LocalDate empDateofJoining, int empDeptID, String empGrade, String empDesignation, int empBasicSal,
			String empGender, String empMaritalStatus, String empHomeAddress, long empContactNum, String mgrId) {
		super();
		this.empID = empID;
		this.empFirstName = empFirstName;
		this.empLastName = empLastName;
		this.empDateofBirth = empDateofBirth;
		this.empDateofJoining = empDateofJoining;
		this.empDeptID = empDeptID;
		this.empGrade = empGrade;
		this.empDesignation = empDesignation;
		this.empBasicSal = empBasicSal;
		this.empGender = empGender;
		this.empMaritalStatus = empMaritalStatus;
		this.empHomeAddress = empHomeAddress;
		this.empContactNum = empContactNum;
		this.mgrId = mgrId;
	}

	public String getEmpID() {
		return empID;
	}
	public void setEmpID(String empID) {
		this.empID = empID;
	}
	public String getEmpFirstName() {
		return empFirstName;
	}
	public void setEmpFirstName(String empFirstName) {
		this.empFirstName = empFirstName;
	}
	public String getEmpLastName() {
		return empLastName;
	}
	public void setEmpLastName(String empLastName) {
		this.empLastName = empLastName;
	}
	public LocalDate getEmpDateofBirth() {
		return empDateofBirth;
	}
	public void setEmpDateofBirth(LocalDate empDateofBirth) {
		this.empDateofBirth = empDateofBirth;
	}
	public LocalDate getEmpDateofJoining() {
		return empDateofJoining;
	}
	public void setEmpDateofJoining(LocalDate empDateofJoining) {
		this.empDateofJoining = empDateofJoining;
	}
	public String getEmpDesignation() {
		return empDesignation;
	}
	public void setEmpDesignation(String empDesignation) {
		this.empDesignation = empDesignation;
	}
	public int getEmpDeptID() {
		return empDeptID;
	}
	public void setEmpDeptID(int empDeptID) {
		this.empDeptID = empDeptID;
	}
	public String getEmpGrade() {
		return empGrade;
	}
	public void setEmpGrade(String empGrade) {
		this.empGrade = empGrade;
	}
	public int getEmpBasicSal() {
		return empBasicSal;
	}
	public void setEmpBasicSal(int empBasicSal) {
		this.empBasicSal = empBasicSal;
	}
	public String getEmpGender() {
		return empGender;
	}
	public void setEmpGender(String empGender) {
		this.empGender = empGender;
	}
	public String getEmpMaritalStatus() {
		return empMaritalStatus;
	}
	public void setEmpMaritalStatus(String empMaritalStatus) {
		this.empMaritalStatus = empMaritalStatus;
	}
	public String getEmpHomeAddress() {
		return empHomeAddress;
	}
	public void setEmpHomeAddress(String empHomeAddress) {
		this.empHomeAddress = empHomeAddress;
	}
	public long getEmpContactNum() {
		return empContactNum;
	}
	public void setEmpContactNum(long empContactNum) {
		this.empContactNum = empContactNum;
	}
	public String getMgrId() {
		return mgrId;
	}
	public void setMgrId(String mgrId) {
		this.mgrId = mgrId;
	}
	@Override
	public String toString() {
		return "Employee [empID=" + empID + ", empFirstName=" + empFirstName + ", empLastName=" + empLastName
				+ ", empDateofBirth=" + empDateofBirth + ", empDateofJoining=" + empDateofJoining + ", empDesignation="
				+ empDesignation + ", empDeptID=" + empDeptID + ", empGrade=" + empGrade + ", empBasicSal="
				+ empBasicSal + ", empGender=" + empGender + ", empMaritalStatus=" + empMaritalStatus
				+ ", empHomeAddress=" + empHomeAddress + ", empContactNum=" + empContactNum + ", mgrId=" + mgrId + "]";
	}
}
