//This is the implementation of the LoginDao interface. The methods are overridden to perform database operations and return appropriate results. 

package com.cg.ems.dao;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.cg.ems.dto.UserMaster;
import com.cg.ems.exception.EmployeeException;
import com.cg.ems.util.DBUtil;
import com.cg.ems.util.QueryMapper;
/*
 * In the LoginDaoImpl class the Connection object is defined which establishes the connection by calling DBUtil class.
 * Statement, Prepared Statements are also defined to perform various database operations.
 * ResultSet is used to store the fetch operations.
 * Logger is defined to log the entire process in a log file. 
 */
public class LoginDaoImpl implements LoginDao {

	Connection con = null;
	Statement st = null;
	PreparedStatement pst = null;
	ResultSet rs = null;
	Logger emsLogger = null;
	public LoginDaoImpl() throws ClassNotFoundException, SQLException, IOException {
		con = DBUtil.getCon();
	}
	/* 
	 * This method will validate the Credential from database
	 * If Credentials are invalid then it will return "Invalid Credential" Message
	 * else It will verify user and give access to its Operations
	 */
	@Override
	public String EmployeeType(UserMaster um) throws SQLException, EmployeeException {
		emsLogger = Logger.getLogger(EmployeeDaoImpl.class);
		PropertyConfigurator.configure("log4j.properties");
		String user = null;
		String name = null;
		String type = null;
		String id = um.getUserId();
		String pass = um.getUserPassword();
		pst = con.prepareStatement(QueryMapper.LOGIN_QRY);
		pst.setString(1, id);
		pst.setString(2, pass);
		rs = pst.executeQuery();
		if (rs.next()) {
			type = rs.getString("UserType");
			name = rs.getString("UserName");
		} else {
			emsLogger.fatal("Invalid Credentials");
			throw new EmployeeException("Invalid Credentials");
		}
		if (type.equals("Admin")) {
			return type;
		} else {
			user = type + " " + name;
			return user;

		}
	}

}
