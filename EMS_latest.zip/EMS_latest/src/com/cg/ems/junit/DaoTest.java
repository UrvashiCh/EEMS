package com.cg.ems.junit;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.ArrayList;

import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;
import com.cg.ems.dao.AdminDao;
import com.cg.ems.dao.AdminDaoImpl;
import com.cg.ems.dao.EmployeeDao;
import com.cg.ems.dao.EmployeeDaoImpl;
import com.cg.ems.dao.LoginDao;
import com.cg.ems.dao.LoginDaoImpl;
import com.cg.ems.dto.Employee;
import com.cg.ems.dto.LeaveRecords;
import com.cg.ems.dto.UserMaster;
import com.cg.ems.exception.EmployeeException;
import com.cg.ems.util.DBUtil;

public class DaoTest {
	static AdminDao adminDaoTest;
	static EmployeeDao empDaoTest;
	static LoginDao loginDaoTest;
	static Connection con = null;
	static Statement st = null;
	static PreparedStatement pst = null;
	static ResultSet rs = null;
	static Employee emp = null;
	static Employee emp1 = null;
	static Employee emp2 = null;
	static UserMaster um1 = null;
	static UserMaster um2 = null;
	static UserMaster um3 = null;
	static LeaveRecords leaveRecord = null;

	@BeforeClass
	public static void setUp() throws ClassNotFoundException, SQLException, IOException {
		emp = new Employee("655457", "Junit", "Test", LocalDate.of(1996, 07, 23), LocalDate.of(2019, 07, 11), 10, "M1",
				"Tester", 20000, "M", "S", "Pune", 9876543211L, "123456");
		leaveRecord = new LeaveRecords("189008", "Rama", LocalDate.of(2019, 10, 3), LocalDate.of(2019, 12, 5), 3,
				"applied", 12);
		emp1 = new Employee("189007", "Archit", "Khandewal", LocalDate.of(1998, 01, 21), LocalDate.of(2019, 07, 11), 30,
				"M5", "Analyst", 5500, "M", "S", "Pune", 9457988920L, "189007");
		emp2 = new Employee("123569", "Junit", "Test", LocalDate.of(1996, 07, 23), LocalDate.of(2019, 07, 11), 10, "M1",
				"Tester", 2000, "M", "S", "Pune", 9876543211L, "189007");
		um1 = new UserMaster("188992", "Amarendra", "ram", "Admin");
		um2 = new UserMaster("188994", "Munni", "munni", "Manager");
		um3 = new UserMaster("188993", "Vivek", "vivek", "Employee");
		loginDaoTest = new LoginDaoImpl();
		adminDaoTest = new AdminDaoImpl();
		empDaoTest = new EmployeeDaoImpl();
		System.out.println("This function is called before the execution of all test cases:");
	}

	/*******************
	 * Add Employee Details Validation Test
	 * 
	 * @throws SQLException
	 * @throws IOException
	 * @throws ClassNotFoundException
	 * @throws EmployeeException
	 ************/

	@Test(expected = EmployeeException.class)
	public void addEmployeeTest() throws SQLException, ClassNotFoundException, IOException, EmployeeException {
		con = DBUtil.getCon();
		con.setAutoCommit(false);
		Assert.assertEquals(1, adminDaoTest.addEmployee(emp));
		con.rollback();
	}

	@Test
	public void LoginTest1() throws ClassNotFoundException, SQLException, IOException, EmployeeException {
		con = DBUtil.getCon();
		Assert.assertEquals("Admin", loginDaoTest.EmployeeType(um1));
	}

	@Test
	public void LoginTest2() throws ClassNotFoundException, SQLException, IOException, EmployeeException {
		con = DBUtil.getCon();
		Assert.assertEquals("Employee Vivek", loginDaoTest.EmployeeType(um3));
	}

	@Test
	public void LoginTest3() throws ClassNotFoundException, SQLException, IOException, EmployeeException {
		con = DBUtil.getCon();
		Assert.assertEquals("Manager Munni", loginDaoTest.EmployeeType(um2));
	}

	@Test
	public void fetchLeaveDurationTest() throws ClassNotFoundException, SQLException, IOException {
		con = DBUtil.getCon();
		Assert.assertEquals(2, empDaoTest.fetchLeaveDuration(1001));
	}

	@Test
	public void fetchInitialLeaveBudget() throws ClassNotFoundException, SQLException, IOException {
		Assert.assertEquals(12, empDaoTest.fetchInitialLeaveBudget("189008"));
	}

	@Test
	public void fetchLeaveBudgetTest() throws ClassNotFoundException, SQLException, IOException {
		Assert.assertEquals(10, empDaoTest.fetchLeaveBudget(1001));
	}

	@Test
	public void newLeaveRequestTest() throws ClassNotFoundException, SQLException, IOException {
		Assert.assertEquals(true, empDaoTest.newLeaveRequest(leaveRecord));
	}

	@Test
	public void updateLeaveRequestTest() throws ClassNotFoundException, SQLException, IOException {
		Assert.assertEquals(true, empDaoTest.updateLeaveRequest(1001, "approved", 10));
	}

	@Test
	public void findEmployeePastLeavesTest() throws ClassNotFoundException, SQLException, IOException {
		Assert.assertEquals(true, empDaoTest.findEmployeePastLeaves("189008"));
	}

	/*******************
	 * Search Employee by ID Validation Test
	 * 
	 * @throws SQLException
	 * @throws IOException
	 * @throws ClassNotFoundException
	 * @throws EmployeeException
	 ************/

	@Test
	public void searchById() throws ClassNotFoundException, SQLException, IOException, EmployeeException {

		Assert.assertEquals(emp1, empDaoTest.searchEmployeeById("189007"));

	}

	/*******************
	 * Search Employee by First Name Validation Test
	 * 
	 * @throws SQLException
	 * @throws IOException
	 * @throws ClassNotFoundException
	 * @throws EmployeeException
	 ************/

	@Test
	public void searchByFirstName() throws ClassNotFoundException, SQLException, IOException, EmployeeException {
		ArrayList<Employee> list = new ArrayList<Employee>();
		list.add(emp);
		list.add(emp2);
		Assert.assertArrayEquals(list.toArray(), empDaoTest.searchEmployeeByFirstName("Junit").toArray());

	}

	/*******************
	 * Search Employee by Last Name Validation Test
	 * 
	 * @throws SQLException
	 * @throws IOException
	 * @throws ClassNotFoundException
	 * @throws EmployeeException
	 ************/

	@Test
	public void searchByLastName() throws ClassNotFoundException, SQLException, IOException, EmployeeException {
		ArrayList<Employee> list = new ArrayList<Employee>();
		list.add(emp);
		list.add(emp2);
		Assert.assertArrayEquals(list.toArray(), empDaoTest.searchEmployeeByLastName("Test").toArray());

	}

	/*******************
	 * Search Employee by Department id Validation Test
	 * 
	 * @throws SQLException
	 * @throws IOException
	 * @throws ClassNotFoundException
	 * @throws EmployeeException
	 ************/

	@Test
	public void searchByDeptid() throws ClassNotFoundException, SQLException, IOException, EmployeeException {
		ArrayList<Employee> list = new ArrayList<Employee>();
		list.add(emp);
		list.add(emp2);
		Assert.assertArrayEquals(list.toArray(), empDaoTest.searchEmployeeByDeptId(10).toArray());
	}

	/*******************
	 * Search Employee by Grade Validation Test
	 * 
	 * @throws SQLException
	 * @throws IOException
	 * @throws ClassNotFoundException
	 * @throws EmployeeException
	 ************/

	@Test
	public void searchByGrade() throws ClassNotFoundException, SQLException, IOException, EmployeeException {
		ArrayList<Employee> list = new ArrayList<Employee>();
		list.add(emp);
		list.add(emp2);
		Assert.assertArrayEquals(list.toArray(), empDaoTest.searchEmployeeByGrade("M1").toArray());

	}

	/*******************
	 * Search Employee by Marital Status Validation Test
	 * 
	 * @throws SQLException
	 * @throws IOException
	 * @throws ClassNotFoundException
	 * @throws EmployeeException
	 ***********/

	@Test
	public void searchByMaritalStatus() throws ClassNotFoundException, SQLException, IOException, EmployeeException {
		ArrayList<Employee> list = new ArrayList<Employee>();
		list.add(emp);
		list.add(emp2);
		list.add(emp1);
		Assert.assertArrayEquals(list.toArray(), empDaoTest.searchEmployeeByMaritalStatus("S").toArray());
	}

}
