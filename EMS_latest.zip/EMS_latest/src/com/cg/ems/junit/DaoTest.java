package com.cg.ems.junit;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.ArrayList;

import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;
import com.cg.ems.dao.AdminDao;
import com.cg.ems.dao.AdminDaoImpl;
import com.cg.ems.dao.EmployeeDao;
import com.cg.ems.dao.EmployeeDaoImpl;
import com.cg.ems.dao.LoginDao;
import com.cg.ems.dao.LoginDaoImpl;
import com.cg.ems.dto.Employee;
import com.cg.ems.dto.LeaveRecords;
import com.cg.ems.dto.UserMaster;
import com.cg.ems.exception.EmployeeException;
import com.cg.ems.util.DBUtil;

public class DaoTest {
	static AdminDao adminDaoTest;
	static EmployeeDao empDaoTest;
	static LoginDao loginDaoTest;
	static Connection con = null;
	static Statement st = null;
	static PreparedStatement pst = null;
	static ResultSet rs = null;
	static Employee emp1 = null;
	static Employee emp2 = null;
	static Employee emp3 = null;
	static UserMaster um1 = null;
	static UserMaster um2 = null;
	static UserMaster um3 = null;
	static LeaveRecords leaveRecord = null;

	@BeforeClass
	public static void setUp() throws ClassNotFoundException, SQLException, IOException {
		emp1 = new Employee("600001", "Junit1", "Test", LocalDate.of(1996, 07, 23), LocalDate.of(2019, 07, 11), 10, "M1","Tester", 20000, "M", "S", "Pune", 9876543211L, "000000");
		emp2 = new Employee("600002", "Junit2", "Test", LocalDate.of(1998, 01, 21), LocalDate.of(2019, 07, 11), 30,"M5", "Analyst", 5500, "M", "S", "Pune", 9457988920L, "000000");
		emp3 = new Employee("600003", "Junit3", "Test", LocalDate.of(1996, 07, 23), LocalDate.of(2019, 07, 11), 10, "M1","Tester", 2000, "M", "S", "Pune", 9876543211L, "000000");
		leaveRecord = new LeaveRecords("6000003", "Junit3", LocalDate.of(2019, 10, 5), LocalDate.of(2019, 12, 3), 3,"applied", 12);
		um1 = new UserMaster("100001", "Admin", "admin", "Admin");
		um2 = new UserMaster("190001", "Archit", "archit", "Manager");
		um3 = new UserMaster("189260", "Shivendra", "shivendra", "Employee");
		loginDaoTest = new LoginDaoImpl();
		adminDaoTest = new AdminDaoImpl();
		empDaoTest = new EmployeeDaoImpl();
		System.out.println("This function is called before the execution of all test cases:");
	}

	/*******************
	 * Add Employee Details Validation Test
	 * 
	 * @throws SQLException
	 * @throws IOException
	 * @throws ClassNotFoundException
	 * @throws EmployeeException
	 ************/

	@Test(expected = EmployeeException.class)
	public void addEmployeeTest1() throws SQLException, ClassNotFoundException, IOException, EmployeeException {
		con = DBUtil.getCon();
		//con.setAutoCommit(false);
		Assert.assertEquals(1, adminDaoTest.addEmployee(emp1));
	//	con.rollback();
	}
	@Test(expected = EmployeeException.class)
	public void addEmployeeTest2() throws SQLException, ClassNotFoundException, IOException, EmployeeException {
		con = DBUtil.getCon();
	//	con.setAutoCommit(false);
		Assert.assertEquals(1, adminDaoTest.addEmployee(emp2));
	//	con.rollback();
	}
	@Test(expected = EmployeeException.class)
	public void addEmployeeTest3() throws SQLException, ClassNotFoundException, IOException, EmployeeException {
		con = DBUtil.getCon();
	//	con.setAutoCommit(false);
		Assert.assertEquals(1, adminDaoTest.addEmployee(emp3));
	//	con.rollback();
	}
	@Test
	public void LoginTest1() throws ClassNotFoundException, SQLException, IOException, EmployeeException {
		con = DBUtil.getCon();
		Assert.assertEquals("Admin", loginDaoTest.EmployeeType(um1));
	}

	@Test
	public void LoginTest2() throws ClassNotFoundException, SQLException, IOException, EmployeeException {
		con = DBUtil.getCon();
		Assert.assertEquals("Employee Shivendra", loginDaoTest.EmployeeType(um3));
	}

	@Test
	public void LoginTest3() throws ClassNotFoundException, SQLException, IOException, EmployeeException {
		con = DBUtil.getCon();
		Assert.assertEquals("Manager Archit", loginDaoTest.EmployeeType(um2));
	}

	

	@Test
	public void fetchInitialLeaveBudget() throws ClassNotFoundException, SQLException, IOException {
		con = DBUtil.getCon();
		Assert.assertEquals(0, empDaoTest.fetchInitialLeaveBudget("600001"));
	}

	@Test
	public void fetchLeaveBudgetTest() throws ClassNotFoundException, SQLException, IOException {
		con = DBUtil.getCon();
		Assert.assertEquals(0, empDaoTest.fetchLeaveBudget(1001));
	}

	/*
	 * @Test public void newLeaveRequestTest() throws ClassNotFoundException,
	 * SQLException, IOException { con = DBUtil.getCon(); Assert.assertEquals(false,
	 * empDaoTest.newLeaveRequest(leaveRecord)); }
	 */

	@Test
	public void updateLeaveRequestTest() throws ClassNotFoundException, SQLException, IOException {
		con = DBUtil.getCon();
		Assert.assertEquals(false, empDaoTest.updateLeaveRequest(1001, "approved", 10));
	}

	@Test
	public void findEmployeePastLeavesTest() throws ClassNotFoundException, SQLException, IOException {
		con = DBUtil.getCon();
		Assert.assertEquals(false, empDaoTest.findEmployeePastLeaves("600001"));
	}

	/*******************
	 * Search Employee by ID Validation Test
	 * 
	 * @throws SQLException
	 * @throws IOException
	 * @throws ClassNotFoundException
	 * @throws EmployeeException
	 ************/

	@Test
	public void searchById() throws ClassNotFoundException, SQLException, IOException, EmployeeException {
		con = DBUtil.getCon();
		Assert.assertEquals(emp1, empDaoTest.searchEmployeeById("600001"));

	}

	/*******************
	 * Search Employee by First Name Validation Test
	 * 
	 * @throws SQLException
	 * @throws IOException
	 * @throws ClassNotFoundException
	 * @throws EmployeeException
	 ************/

	@Test
	public void searchByFirstName() throws ClassNotFoundException, SQLException, IOException, EmployeeException {
		con = DBUtil.getCon();
		ArrayList<Employee> list = new ArrayList<Employee>();
		list.add(emp1);
		//list.add(emp2);
		Assert.assertArrayEquals(list.toArray(), empDaoTest.searchEmployeeByFirstName("Junit1").toArray());

	}

	/*******************
	 * Search Employee by Last Name Validation Test
	 * 
	 * @throws SQLException
	 * @throws IOException
	 * @throws ClassNotFoundException
	 * @throws EmployeeException
	 ************/

	@Test
	public void searchByLastName() throws ClassNotFoundException, SQLException, IOException, EmployeeException {
		con = DBUtil.getCon();
		ArrayList<Employee> list = new ArrayList<Employee>();
		list.add(emp2);
		list.add(emp3);
		list.add(emp1);
		Assert.assertArrayEquals(list.toArray(), empDaoTest.searchEmployeeByLastName("Test").toArray());

	}


}
