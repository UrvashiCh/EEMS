package com.cg.ems.junit;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;

import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.ems.dao.AdminDao;
import com.cg.ems.dao.AdminDaoImpl;
import com.cg.ems.dto.Employee;
import com.cg.ems.dto.LeaveRecords;
import com.cg.ems.dto.UserMaster;
import com.cg.ems.exception.EmployeeException;
import com.cg.ems.util.DBUtil;

public class DaoTest 
{
static AdminDao adminDaoTest;
static Connection con=null;
static Statement st=null;
static PreparedStatement pst=null;
static ResultSet rs=null;
static Employee emp=null;
static LeaveRecords leaveRecords = null;
	@BeforeClass
	public static void setUp()
	{
		emp=new Employee("987354", "Junit", "Test", LocalDate.of(1996, 07, 23), LocalDate.of(2019,07, 11), 10, "M1", "Tester", 20000, "M","S", "Pune", 9876543211L, "123456");
		adminDaoTest = new AdminDaoImpl();
		System.out.println("This function is called before the execution of all test cases:");
	}
	
	/*******************Add Employee Details Validation Test************/
	
	@Test
	public void addEmployeeTest1()
	{
		try {
			con = DBUtil.getCon();
			con.setAutoCommit(false);
			Assert.assertEquals(1,adminDaoTest.addEmployee(emp));
			con.rollback();
		} catch (ClassNotFoundException | EmployeeException | SQLException | IOException e) {
			e.printStackTrace();
		}
	}
	
	
	@Test
	public void salaryBracket1()
	{
		try {
			con = DBUtil.getCon();
			con.setAutoCommit(false);
			Assert.assertEquals(3000,adminDaoTest.salaryBracket("M3")[0]);
			con.rollback();
		} catch (ClassNotFoundException | EmployeeException | SQLException | IOException e) {
			e.printStackTrace();
		}
	}
	
	@Test
	public void getDepartment1()
	{
		try {
			con = DBUtil.getCon();
			con.setAutoCommit(false);
			Assert.assertEquals(1,adminDaoTest.addEmployee(emp));
			con.rollback();
		} catch (ClassNotFoundException | EmployeeException | SQLException | IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	@Test
	public void addLogin1()
	{
		try {
			con = DBUtil.getCon();
			con.setAutoCommit(false);
			Assert.assertEquals(1,adminDaoTest.addEmployee(emp));
			con.rollback();
		} catch (ClassNotFoundException | EmployeeException | SQLException | IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	@Test
	public void fetchEmpName1()
	{
		try {
			con = DBUtil.getCon();
			con.setAutoCommit(false);
			Assert.assertEquals(1,adminDaoTest.addEmployee(emp));
			con.rollback();
		} catch (ClassNotFoundException | EmployeeException | SQLException | IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	@Test
	public void getEmployeeById1()
	{
		try {
			con = DBUtil.getCon();
			con.setAutoCommit(false);
			Assert.assertEquals(1,adminDaoTest.addEmployee(emp));
			con.rollback();
		} catch (ClassNotFoundException | EmployeeException | SQLException | IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	@Test
	public void updateEmployee()
	{
		try {
			con = DBUtil.getCon();
			con.setAutoCommit(false);
			Assert.assertEquals(1,adminDaoTest.addEmployee(emp));
			con.rollback();
		} catch (ClassNotFoundException | EmployeeException | SQLException | IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	@Test
	public void EmployeeType1()
	{
		try {
			con = DBUtil.getCon();
			con.setAutoCommit(false);
			Assert.assertEquals(1,adminDaoTest.addEmployee(emp));
			con.rollback();
		} catch (ClassNotFoundException | EmployeeException | SQLException | IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	@Test
	public void searchEmployeeById1()
	{
		try {
			con = DBUtil.getCon();
			con.setAutoCommit(false);
			Assert.assertEquals(1,adminDaoTest.addEmployee(emp));
			con.rollback();
		} catch (ClassNotFoundException | EmployeeException | SQLException | IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	@Test
	public void fetchLeaveDuration1()
	{
		try {
			con = DBUtil.getCon();
			con.setAutoCommit(false);
			Assert.assertEquals(1,adminDaoTest.addEmployee(emp));
			con.rollback();
		} catch (ClassNotFoundException | EmployeeException | SQLException | IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	@Test
	public void fetchInitialLeaveBudget1()
	{
		try {
			con = DBUtil.getCon();
			con.setAutoCommit(false);
			Assert.assertEquals(1,adminDaoTest.addEmployee(emp));
			con.rollback();
		} catch (ClassNotFoundException | EmployeeException | SQLException | IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	@Test
	public void newLeaveRequest1()
	{
		try {
			con = DBUtil.getCon();
			con.setAutoCommit(false);
			Assert.assertEquals(1,adminDaoTest.addEmployee(emp));
			con.rollback();
		} catch (ClassNotFoundException | EmployeeException | SQLException | IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	@Test
	public void updateLeaveRequest1()
	{
		try {
			con = DBUtil.getCon();
			con.setAutoCommit(false);
			Assert.assertEquals(1,adminDaoTest.addEmployee(emp));
			con.rollback();
		} catch (ClassNotFoundException | EmployeeException | SQLException | IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	@Test
	public void fetchLeaveBudget1()
	{
		try {
			con = DBUtil.getCon();
			con.setAutoCommit(false);
			Assert.assertEquals(1,adminDaoTest.addEmployee(emp));
			con.rollback();
		} catch (ClassNotFoundException | EmployeeException | SQLException | IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	@Test
	public void findEmployeePastLeaves1()
	{
		try {
			con = DBUtil.getCon();
			con.setAutoCommit(false);
			Assert.assertEquals(1,adminDaoTest.addEmployee(emp));
			con.rollback();
		} catch (ClassNotFoundException | EmployeeException | SQLException | IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
