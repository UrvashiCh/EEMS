package com.cg.ems.service;

public class EmployeeServiceImpl implements EmployeeService
{

}
